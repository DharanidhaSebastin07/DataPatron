"""
MCA/llm.py — Databricks LLM Client
=====================================
Handles all LLM communication. Imported by new_mca.py.
"""

import json
import re
import logging
import requests

DATABRICKS_HOST  = "https://dbc-14f40aec-e3df.cloud.databricks.com"
DATABRICKS_TOKEN = "dapi451414add2143f2b0642788e8313c1b1"
MODEL_ENDPOINT   = "databricks-meta-llama-3-3-70b-instruct"

logger = logging.getLogger("MCA.llm")


class LLMParseError(Exception):
    """Raised when LLM response cannot be parsed as valid JSON."""

class LLMCallError(Exception):
    """Raised when the LLM HTTP request fails."""


def extract_json(text: str) -> dict:
    """Safely pull a JSON object out of raw LLM output."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    fenced = re.sub(r"```(?:json)?", "", text).strip()
    try:
        return json.loads(fenced)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    raise LLMParseError(f"Could not extract JSON from LLM output:\n{text}")


class DatabricksLLMClient:

    def __init__(
        self,
        host: str          = DATABRICKS_HOST,
        token: str         = DATABRICKS_TOKEN,
        model: str         = MODEL_ENDPOINT,
        temperature: float = 0.1,
        max_tokens: int    = 1500,
        timeout: int       = 60,
    ):
        self.url         = f"{host}/serving-endpoints/{model}/invocations"
        self.headers     = {
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/json",
        }
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self.timeout     = timeout

    def call(self, system_prompt: str, user_prompt: str) -> str:
        payload = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt},
            ],
            "temperature": self.temperature,
            "max_tokens":  self.max_tokens,
        }
        logger.info("Calling LLM: %s", self.url)
        try:
            response = requests.post(
                self.url, headers=self.headers, json=payload, timeout=self.timeout
            )
            response.raise_for_status()
        except requests.exceptions.Timeout:
            raise LLMCallError("LLM request timed out.")
        except requests.exceptions.ConnectionError as exc:
            raise LLMCallError(f"Network error: {exc}")
        except requests.exceptions.HTTPError as exc:
            raise LLMCallError(f"HTTP {response.status_code}: {response.text}")

        result = response.json()
        if "choices" not in result or not result["choices"]:
            raise LLMCallError(f"Unexpected LLM response: {result}")
        raw = result["choices"][0]["message"]["content"]
        if not raw or not raw.strip():
            raise LLMCallError("LLM returned empty response.")
        return raw

    def parse_user_intent(self, user_input: str) -> dict:
        system = (
            "You are a data ingestion pipeline planner. "
            "Decompose the user request into INDIVIDUAL pipeline entries. "
            "Rules: "
            "1. Each S3 bucket = one separate source entry. "
            "2. Each Azure SQL database = one separate source entry. "
            "3. Never group multiple buckets or schemas into one entry. "
            "4. Supported source_type values: azure_sql, s3, rest_api, postgresql. "
            "5. Return VALID JSON ONLY. No markdown, no comments, no explanation."
        )
        user = f"""
User ingestion request:
{user_input}

RULES:
- Do NOT fill in bucket names, schema names, or connection details.
- Only identify: source_type, ingestion_mode, schedule, and COUNT of pipelines.
- 2 S3 buckets → 2 separate s3 entries.
- 2 Azure SQL databases → 2 separate azure_sql entries.

EXAMPLE — "2 S3 buckets and 2 Azure SQL databases":
{{
  "sources": [
    {{"source_type": "s3",        "ingestion_mode": "full", "schedule": "one_time"}},
    {{"source_type": "s3",        "ingestion_mode": "full", "schedule": "one_time"}},
    {{"source_type": "azure_sql", "ingestion_mode": "full", "schedule": "one_time"}},
    {{"source_type": "azure_sql", "ingestion_mode": "full", "schedule": "one_time"}}
  ],
  "destination": {{"catalog": "bronze_catalog", "schema": "raw_ingestion"}}
}}

Return JSON for the actual request only. No bucket names. No connection details.
"""
        logger.info("Parsing user intent via LLM.")
        raw = self.call(system, user)
        logger.debug("Raw LLM output:\n%s", raw)
        return extract_json(raw)