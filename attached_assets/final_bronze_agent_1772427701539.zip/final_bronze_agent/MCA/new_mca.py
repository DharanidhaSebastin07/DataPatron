# """
# MCA/new_mca.py — Master Control Agent (MCA)
# ============================================
# Step 1 of the orchestration pipeline. Called by orchestrator.py.

# Imports sibling files from the same MCA/ folder:
#     llm.py  — Databricks LLM client
#     s3.py   — AWS S3 handler
#     sql.py  — Azure SQL handler
#     pg.py   — PostgreSQL handler
#     rest_handler.py — REST API handler

# Does NOT collect credentials — that is cred.py (Step 2).
# """

# import sys
# import os
# sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# import json
# import uuid
# import logging
# from datetime import datetime, timezone

# from llm import DatabricksLLMClient, LLMCallError, LLMParseError
# import s3
# import sql
# import pg
# import rest

# logger = logging.getLogger("MCA")

# VALID_MODES     = {"full", "incremental"}
# VALID_SCHEDULES = {"one_time", "hourly", "daily"}

# # Maps source_type string → handler module (s3.py, sql.py, pg.py, rest.py)
# SOURCE_HANDLERS = {
#     "s3":         s3,
#     "azure_sql":  sql,
#     "postgresql": pg,
#     "rest_api":   rest,
# }

# SUPPORTED_SOURCES = set(SOURCE_HANDLERS.keys())


# # =============================================================================
# # EXCEPTIONS
# # =============================================================================

# class ValidationError(Exception):
#     """Raised when parsed intent fails business-rule validation."""


# # =============================================================================
# # INTENT VALIDATOR
# # =============================================================================

# class IntentValidator:

#     @staticmethod
#     def validate(parsed: dict) -> None:
#         if "sources" not in parsed or not isinstance(parsed["sources"], list):
#             raise ValidationError("Parsed intent is missing a 'sources' list.")
#         if not parsed["sources"]:
#             raise ValidationError("No ingestion sources identified in request.")

#         for idx, source in enumerate(parsed["sources"], 1):
#             src_type = source.get("source_type", "").lower()
#             if src_type not in SUPPORTED_SOURCES:
#                 raise ValidationError(
#                     f"Source #{idx} unsupported type '{src_type}'. "
#                     f"Supported: {SUPPORTED_SOURCES}"
#                 )
#             mode = source.get("ingestion_mode", "full").lower()
#             if mode not in VALID_MODES:
#                 raise ValidationError(
#                     f"Source #{idx} invalid ingestion_mode '{mode}'."
#                 )
#             schedule = source.get("schedule", "one_time").lower()
#             if schedule not in VALID_SCHEDULES:
#                 raise ValidationError(
#                     f"Source #{idx} invalid schedule '{schedule}'."
#                 )

#         logger.info("Validation passed — %d source(s).", len(parsed["sources"]))

#     @staticmethod
#     def split(parsed: dict) -> dict:
#         """
#         Safety net: if the LLM grouped multiple buckets/schemas into one entry,
#         each handler's split_entries() expands them into one entry each.
#         """
#         expanded = []
#         for source in parsed.get("sources", []):
#             handler = SOURCE_HANDLERS.get(source.get("source_type", "").lower())
#             expanded.extend(handler.split_entries(source) if handler else [source])

#         before, after = len(parsed["sources"]), len(expanded)
#         if after != before:
#             logger.info("Split: %d → %d pipelines", before, after)

#         parsed["sources"] = expanded
#         return parsed


# # =============================================================================
# # MASTER CONTROL AGENT
# # =============================================================================

# class MasterControlAgent:
#     """
#     Called by orchestrator.py as Step 1.

#         agent = MasterControlAgent()
#         plan, path = agent.execute(user_input, output_dir=output_dir)
#     """

#     def __init__(self, llm_client: DatabricksLLMClient | None = None):
#         self.llm       = llm_client or DatabricksLLMClient()
#         self.validator = IntentValidator()

#     def execute(self, user_input: str, output_dir: str = ".") -> tuple:
#         """
#         Parse the user request, build pipeline skeletons, save plan JSON.

#         Args:
#             user_input : Natural-language ingestion request (passed from orchestrator).
#             output_dir : Where to save the plan JSON.

#         Returns:
#             (plan_dict, plan_filepath)
#             All connection_template fields are empty.
#             Pipeline status = 'awaiting_credentials'.
#         """
#         if not user_input or not user_input.strip():
#             raise ValueError("User input cannot be empty.")

#         logger.info("MCA started.")
#         session_id = f"session_{uuid.uuid4().hex[:10]}"
#         logger.info("Session ID: %s", session_id)

#         # A — LLM parses the request
#         print("  ⏳ Analysing request via LLM...")
#         parsed = self.llm.parse_user_intent(user_input)

#         # B — Validate
#         self.validator.validate(parsed)

#         # C — Split into one entry per bucket / database / schema
#         parsed = self.validator.split(parsed)

#         total = len(parsed["sources"])
#         print(f"  ✅ {total} pipeline(s) identified.\n")
#         logger.info("Total pipelines: %d", total)

#         # D — Build pipeline skeletons (credentials left empty)
#         pipelines = []
#         for idx, source in enumerate(parsed["sources"], 1):
#             src_type = source["source_type"].lower()
#             handler  = SOURCE_HANDLERS.get(src_type)
#             if handler is None:
#                 raise ValidationError(f"No handler for source type: '{src_type}'")
#             pipelines.append(handler.build_pipeline(session_id, idx, source))

#         # E — Assemble & save plan
#         plan = {
#             "session_id":      session_id,
#             "created_at":      datetime.now(timezone.utc).isoformat(),
#             "stage":           "awaiting_credentials",
#             "destination":     parsed.get("destination", {
#                 "catalog": "bronze_catalog",
#                 "schema":  "raw_ingestion",
#             }),
#             "total_pipelines": total,
#             "pipelines":       pipelines,
#         }

#         os.makedirs(output_dir, exist_ok=True)
#         plan_path = os.path.join(output_dir, f"mca_plan_{session_id}.json")
#         with open(plan_path, "w", encoding="utf-8") as f:
#             json.dump(plan, f, indent=2, ensure_ascii=False)

#         logger.info("MCA plan saved → %s", plan_path)
#         return plan, plan_path



"""
MCA/new_mca.py — Master Control Agent (MCA)
Step 1 of the orchestration pipeline. Called by orchestrator.py.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json
import uuid
import logging
from datetime import datetime, timezone

from llm import DatabricksLLMClient, LLMCallError, LLMParseError
import s3
import sql
import pg
import rest_handler as rest   # ← FIXED: was "import rest"

logger = logging.getLogger("MCA")

VALID_MODES     = {"full", "incremental"}
VALID_SCHEDULES = {"one_time", "hourly", "daily"}

SOURCE_HANDLERS = {
    "s3":         s3,
    "azure_sql":  sql,
    "postgresql": pg,
    "rest_api":   rest,
}

SUPPORTED_SOURCES = set(SOURCE_HANDLERS.keys())


class ValidationError(Exception):
    pass


class IntentValidator:

    @staticmethod
    def validate(parsed: dict) -> None:
        if "sources" not in parsed or not isinstance(parsed["sources"], list):
            raise ValidationError("Parsed intent is missing a 'sources' list.")
        if not parsed["sources"]:
            raise ValidationError("No ingestion sources identified in request.")

        for idx, source in enumerate(parsed["sources"], 1):
            src_type = source.get("source_type", "").lower()
            if src_type not in SUPPORTED_SOURCES:
                raise ValidationError(
                    f"Source #{idx} unsupported type '{src_type}'. "
                    f"Supported: {SUPPORTED_SOURCES}"
                )
            mode = source.get("ingestion_mode", "full").lower()
            if mode not in VALID_MODES:
                raise ValidationError(
                    f"Source #{idx} invalid ingestion_mode '{mode}'."
                )
            schedule = source.get("schedule", "one_time").lower()
            if schedule not in VALID_SCHEDULES:
                raise ValidationError(
                    f"Source #{idx} invalid schedule '{schedule}'."
                )

        logger.info("Validation passed — %d source(s).", len(parsed["sources"]))

    @staticmethod
    def split(parsed: dict) -> dict:
        expanded = []
        for source in parsed.get("sources", []):
            handler = SOURCE_HANDLERS.get(source.get("source_type", "").lower())
            expanded.extend(handler.split_entries(source) if handler else [source])

        before, after = len(parsed["sources"]), len(expanded)
        if after != before:
            logger.info("Split: %d → %d pipelines", before, after)

        parsed["sources"] = expanded
        return parsed


class MasterControlAgent:

    def __init__(self, llm_client: DatabricksLLMClient | None = None):
        self.llm       = llm_client or DatabricksLLMClient()
        self.validator = IntentValidator()

    def execute(self, user_input: str, output_dir: str = ".") -> tuple:
        if not user_input or not user_input.strip():
            raise ValueError("User input cannot be empty.")

        logger.info("MCA started.")
        session_id = f"session_{uuid.uuid4().hex[:10]}"
        logger.info("Session ID: %s", session_id)

        print("  ⏳ Analysing request via LLM...")
        parsed = self.llm.parse_user_intent(user_input)

        self.validator.validate(parsed)
        parsed = self.validator.split(parsed)

        total = len(parsed["sources"])
        print(f"  ✅ {total} pipeline(s) identified.\n")
        logger.info("Total pipelines: %d", total)

        pipelines = []
        for idx, source in enumerate(parsed["sources"], 1):
            src_type = source["source_type"].lower()
            handler  = SOURCE_HANDLERS.get(src_type)
            if handler is None:
                raise ValidationError(f"No handler for source type: '{src_type}'")
            pipelines.append(handler.build_pipeline(session_id, idx, source))

        plan = {
            "session_id":      session_id,
            "created_at":      datetime.now(timezone.utc).isoformat(),
            "stage":           "awaiting_credentials",
            "destination":     parsed.get("destination", {
                "catalog": "bronze_catalog",
                "schema":  "raw_ingestion",
            }),
            "total_pipelines": total,
            "pipelines":       pipelines,
        }

        os.makedirs(output_dir, exist_ok=True)
        plan_path = os.path.join(output_dir, f"mca_plan_{session_id}.json")
        with open(plan_path, "w", encoding="utf-8") as f:
            json.dump(plan, f, indent=2, ensure_ascii=False)

        logger.info("MCA plan saved → %s", plan_path)
        return plan, plan_path
