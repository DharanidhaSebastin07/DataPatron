# # """
# # MCA/rest.py — REST API Source Handler
# # ========================================
# # Imported by new_mca.py.
# # Exposes: build_pipeline(), build_connection_template(), split_entries()

# # Uses Python engine (not Spark). No splitting needed.
# # """

# # from datetime import datetime, timezone

# # EXECUTION_ENGINE = "python"


# # def build_connection_template() -> dict:
# #     """Empty REST API credential template — filled by cred.py (Step 2)."""
# #     return {
# #         "endpoint":  "",
# #         "auth_type": "",   # none | api_key | bearer | basic
# #         "api_key":   "",
# #     }


# # def build_pipeline(session_id: str, idx: int, source: dict) -> dict:
# #     return {
# #         "pipeline_id":         f"{session_id}_pipeline_{idx:03d}",
# #         "source_type":         "rest_api",
# #         "ingestion_mode":      source.get("ingestion_mode", "full").lower(),
# #         "schedule":            source.get("schedule", "one_time").lower(),
# #         "execution_engine":    EXECUTION_ENGINE,
# #         "connection_template": build_connection_template(),
# #         "status":              "awaiting_credentials",
# #         "created_at":          datetime.now(timezone.utc).isoformat(),
# #     }


# # def split_entries(source: dict) -> list:
# #     """REST API — each entry is already one endpoint. No splitting needed."""
# #     return [source]


# """
# CRED/rest.py — REST API Credential Collector
# ==============================================
# Handles interactive prompting and validation for REST API pipelines.
# Imported by cred.py.
# """

# import getpass

# REQUIRED_FIELDS  = ["endpoint", "auth_type"]
# SENSITIVE_FIELDS = {"api_key"}

# AUTH_TYPES = ["none", "api_key", "bearer", "basic"]

# # Common header names shown as hint to the user
# _HEADER_HINT = "e.g. X-API-Key, Authorization, X-Auth-Token, Api-Key"


# def collect(pipeline_id: str, conn: dict) -> dict:
#     """
#     Interactively prompt the user for all empty REST API credential fields.
#     Returns the fully populated connection dict.
#     """
#     print(f"\n  [REST API] Connection details for: {pipeline_id}\n")

#     if not conn.get("endpoint"):
#         conn["endpoint"] = _ask("Endpoint URL  (e.g. https://api.example.com/v1/data)")

#     if not conn.get("auth_type"):
#         conn["auth_type"] = _ask_choice("Auth type", AUTH_TYPES)

#     if conn["auth_type"] == "api_key":
#         # Ask which header name the API actually expects
#         if not conn.get("header_name"):
#             conn["header_name"] = _ask(
#                 f"Header name for the API key  ({_HEADER_HINT})"
#             )
#         if not conn.get("api_key"):
#             conn["api_key"] = _ask_secret("API key value")

#     elif conn["auth_type"] == "bearer":
#         if not conn.get("api_key"):
#             conn["api_key"] = _ask_secret("Bearer token")
#         conn["header_name"] = "Authorization"   # always fixed for bearer

#     elif conn["auth_type"] == "basic":
#         if not conn.get("api_key"):
#             conn["api_key"] = _ask_secret("Base64 credentials (user:password)")
#         conn["header_name"] = "Authorization"   # always fixed for basic

#     return conn


# def validate(conn: dict, pipeline_id: str) -> list:
#     """Return list of missing required field names."""
#     missing = [f for f in REQUIRED_FIELDS if not conn.get(f)]

#     auth = conn.get("auth_type", "none")
#     if auth != "none":
#         if not conn.get("api_key"):
#             missing.append("api_key")
#         if auth == "api_key" and not conn.get("header_name"):
#             missing.append("header_name")

#     return missing


# # =============================================================================
# # INPUT HELPERS
# # =============================================================================

# def _ask(prompt: str) -> str:
#     while True:
#         value = input(f"    {prompt}: ").strip()
#         if value:
#             return value
#         print("    ⚠  Required field — please enter a value.")


# def _ask_secret(prompt: str) -> str:
#     while True:
#         value = getpass.getpass(f"    {prompt}: ").strip()
#         if value:
#             return value
#         print("    ⚠  Required field.")


# def _ask_choice(prompt: str, options: list) -> str:
#     while True:
#         value = input(f"    {prompt}  [{' / '.join(options)}]: ").strip().lower()
#         if value in options:
#             return value
#         print(f"    ⚠  Must be one of: {', '.join(options)}")

"""
MCA/rest_handler.py — REST API Source Handler
Imported by new_mca.py.
Exposes: build_pipeline(), build_connection_template(), split_entries()
"""

from datetime import datetime, timezone

EXECUTION_ENGINE = "python"


def build_connection_template() -> dict:
    return {
        "endpoint":    "",
        "auth_type":   "",   # none | api_key | bearer | basic
        "api_key":     "",
        "header_name": "",
    }


def build_pipeline(session_id: str, idx: int, source: dict) -> dict:
    return {
        "pipeline_id":         f"{session_id}_pipeline_{idx:03d}",
        "source_type":         "rest_api",
        "ingestion_mode":      source.get("ingestion_mode", "full").lower(),
        "schedule":            source.get("schedule", "one_time").lower(),
        "execution_engine":    EXECUTION_ENGINE,
        "connection_template": build_connection_template(),
        "status":              "awaiting_credentials",
        "created_at":          datetime.now(timezone.utc).isoformat(),
    }


def split_entries(source: dict) -> list:
    return [source]