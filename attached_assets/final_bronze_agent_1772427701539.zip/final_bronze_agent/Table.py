# """
# TABLE/Table.py — Table Creation Agent
# =======================================
# Step 7 of the orchestration pipeline.

# Approval layer for each table:
#   - Shows the extracted table name (from schema file)
#   - Suggests a cleaner alternative name
#   - User picks: original, suggestion, or their own custom name
#   - Or skips the table entirely
# """

# import json
# import os
# import re
# import requests
# import time


# # =============================================================================
# # NAME SUGGESTER
# # =============================================================================

# def _suggest_name(raw_table_name: str) -> str:
#     """
#     Generate a cleaner suggested table name from the raw extracted name.

#     Rules applied:
#       - Lowercase
#       - Strip common file extensions (.csv, .json, .parquet, .xlsx)
#       - Replace spaces, hyphens, dots with underscores
#       - Remove consecutive underscores
#       - Strip leading/trailing underscores
#       - Prefix with 'raw_' to make the bronze layer intent explicit
#     """
#     name = raw_table_name.lower()

#     # Remove file extensions
#     for ext in [".csv", ".json", ".parquet", ".xlsx", ".tsv"]:
#         name = name.replace(ext, "")

#     # Replace non-alphanumeric characters with underscores
#     name = re.sub(r"[^a-z0-9]+", "_", name)

#     # Collapse multiple underscores, strip edges
#     name = re.sub(r"_+", "_", name).strip("_")

#     # Prefix with raw_ if not already
#     if not name.startswith("raw_"):
#         name = f"raw_{name}"

#     return name


# # =============================================================================
# # USER APPROVAL LAYER  —  comparison style
# # =============================================================================

# def _approve_table(full_table_name: str, ddl: str) -> tuple:
#     """
#     Show a side-by-side comparison of the proposed name vs Claude's suggestion,
#     then let the user pick which one to use (or enter their own).

#     Returns:
#         (approved_table_name, approved_ddl)  — name chosen/entered by user
#         (None, None)                          — if skipped
#     """
#     # Split into prefix (catalog.schema) and just the table part
#     parts      = full_table_name.rsplit(".", 1)
#     prefix     = parts[0] if len(parts) == 2 else ""
#     table_part = parts[1] if len(parts) == 2 else full_table_name

#     suggested_part = _suggest_name(table_part)
#     suggested_full = f"{prefix}.{suggested_part}" if prefix else suggested_part

#     print("\n" + "═" * 65)
#     print("  TABLE NAME REVIEW")
#     print("═" * 65)
#     print(f"  Extracted name  (1) : {full_table_name}")
#     print(f"  Suggested name  (2) : {suggested_full}")
#     print("─" * 65)
#     print("\n  DDL Preview (using extracted name):")
#     for line in ddl.splitlines():
#         print(f"    {line}")
#     print("═" * 65)

#     while True:
#         print("\n  Options:")
#         print(f"    [1] Use extracted name  → {full_table_name}")
#         print(f"    [2] Use suggested name  → {suggested_full}")
#         print( "    [3] Enter a custom name")
#         print( "    [S] Skip this table")

#         choice = input("\n  Your choice [1 / 2 / 3 / S]: ").strip().upper()

#         if choice == "1":
#             print(f"  ✅ Using extracted name: {full_table_name}")
#             return full_table_name, ddl

#         elif choice == "2":
#             new_ddl = ddl.replace(full_table_name, suggested_full, 1)
#             print(f"  ✅ Using suggested name: {suggested_full}")
#             return suggested_full, new_ddl

#         elif choice == "3":
#             custom = input(
#                 "  Enter your table name (table part only, not catalog/schema): "
#             ).strip().lower().replace(" ", "_")

#             if not custom:
#                 print("  ⚠  Name cannot be empty. Try again.")
#                 continue

#             custom_full = f"{prefix}.{custom}" if prefix else custom
#             new_ddl     = ddl.replace(full_table_name, custom_full, 1)
#             print(f"  ✅ Using custom name: {custom_full}")
#             return custom_full, new_ddl

#         elif choice == "S":
#             print(f"  ⏭  Skipped: {full_table_name}")
#             return None, None

#         else:
#             print("  ⚠  Invalid choice. Enter 1, 2, 3, or S.")


# # =============================================================================
# # TABLE CREATION AGENT
# # =============================================================================

# class TableCreationAgent:

#     def __init__(self, schema_file: str, output_file: str = "table_creation_status.json"):
#         self.schema_file = schema_file
#         self.output_file = output_file

#     def execute(
#         self,
#         workspace_url: str | None = None,
#         warehouse_id:  str | None = None,
#         token:         str | None = None,
#         catalog:       str | None = None,
#         schema_name:   str | None = None,
#         auto_approve:  bool       = False,
#     ):
#         schema_data = self._load_json(self.schema_file)

#         if not workspace_url:
#             print("\n=== DESTINATION DETAILS ===")
#             workspace_url = input("  Databricks Workspace URL        : ").strip().rstrip("/")
#             warehouse_id  = input("  Databricks Warehouse ID         : ").strip()
#             token         = input("  Databricks Personal Access Token: ").strip()
#             catalog       = input("  Catalog name                    : ").strip()
#             schema_name   = input("  Schema name                     : ").strip()

#         headers = {
#             "Authorization": f"Bearer {token}",
#             "Content-Type":  "application/json",
#         }

#         results        = []
#         created_tables = set()

#         try:
#             # ── Create catalog ────────────────────────────────────────
#             print(f"\n  Creating catalog : {catalog}")
#             self._execute_sql(
#                 workspace_url, warehouse_id, headers,
#                 f"CREATE CATALOG IF NOT EXISTS {catalog}",
#             )

#             # ── Create schema ─────────────────────────────────────────
#             print(f"  Creating schema  : {catalog}.{schema_name}")
#             self._execute_sql(
#                 workspace_url, warehouse_id, headers,
#                 f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema_name}",
#             )

#             # ── Process each table ────────────────────────────────────
#             tables = schema_data.get("tables", [])
#             print(f"\n  {len(tables)} table(s) found in schema file.")

#             for idx, table in enumerate(tables, 1):
#                 raw_name     = table.get("table_name", f"table_{idx}")
#                 columns      = table.get("columns", [])
#                 partition_by = table.get("partition_by")

#                 table_part      = self._clean_name(raw_name)
#                 full_table_name = f"{catalog}.{schema_name}.{table_part}"

#                 if full_table_name in created_tables:
#                     continue

#                 # Build DDL
#                 try:
#                     ddl = self._build_ddl(full_table_name, columns, partition_by)
#                 except Exception as exc:
#                     results.append({
#                         "table_name": full_table_name,
#                         "status":     "failed",
#                         "error":      str(exc),
#                     })
#                     continue

#                 # ── APPROVAL / NAME COMPARISON ────────────────────────
#                 if auto_approve:
#                     approved_name = full_table_name
#                     approved_ddl  = ddl
#                 else:
#                     approved_name, approved_ddl = _approve_table(full_table_name, ddl)

#                 if approved_name is None:
#                     results.append({
#                         "table_name": full_table_name,
#                         "status":     "skipped",
#                     })
#                     continue

#                 # ── Execute DDL ───────────────────────────────────────
#                 try:
#                     self._execute_sql(workspace_url, warehouse_id, headers, approved_ddl)
#                     results.append({
#                         "table_name":          approved_name,
#                         "original_table_name": full_table_name,
#                         "status":              "created",
#                     })
#                     created_tables.add(approved_name)

#                 except Exception as exc:
#                     results.append({
#                         "table_name": approved_name,
#                         "status":     "failed",
#                         "error":      str(exc),
#                     })

#         except Exception as exc:
#             print(f"\n❌ Fatal error: {exc}")

#         # ── Save & print summary ──────────────────────────────────────
#         final_output = {"catalog": catalog, "schema": schema_name, "tables": results}
#         self._save_json(final_output)

#         created = sum(1 for r in results if r["status"] == "created")
#         skipped = sum(1 for r in results if r["status"] == "skipped")
#         failed  = sum(1 for r in results if r["status"] == "failed")

#         print("\n" + "=" * 65)
#         print("  TABLE CREATION COMPLETE")
#         print(f"  Created : {created}")
#         print(f"  Skipped : {skipped}")
#         print(f"  Failed  : {failed}")
#         print("=" * 65)

#     # ------------------------------------------------------------------
#     def _build_ddl(self, full_table_name: str, columns: list, partition_by) -> str:
#         if not columns:
#             raise Exception(f"No columns defined for {full_table_name}")
#         col_defs = [
#             f"{c['name'].lower().replace(' ', '_')} {c['type'].upper()}"
#             for c in columns
#         ]
#         ddl = (
#             f"CREATE TABLE IF NOT EXISTS {full_table_name} (\n"
#             f"    {',\n    '.join(col_defs)}\n"
#             f")\nUSING DELTA"
#         )
#         if partition_by:
#             parts = ", ".join(p.lower().replace(" ", "_") for p in partition_by)
#             ddl  += f"\nPARTITIONED BY ({parts})"
#         return ddl

#     @staticmethod
#     def _clean_name(raw_name: str) -> str:
#         name = raw_name.split(".")[-1] if "." in raw_name else raw_name
#         return name.replace(".csv", "").replace(" ", "_").lower()

#     def _execute_sql(self, workspace_url, warehouse_id, headers, sql):
#         response = requests.post(
#             f"{workspace_url}/api/2.0/sql/statements",
#             headers=headers,
#             json={"statement": sql, "warehouse_id": warehouse_id},
#         )
#         if response.status_code != 200:
#             raise Exception(f"SQL Submit Failed: {response.text}")

#         stmt_id    = response.json()["statement_id"]
#         status_url = f"{workspace_url}/api/2.0/sql/statements/{stmt_id}"
#         start      = time.time()

#         while True:
#             sr    = requests.get(status_url, headers=headers)
#             if sr.status_code != 200:
#                 raise Exception(f"Status Check Failed: {sr.text}")
#             state = sr.json()["status"]["state"]

#             if state == "SUCCEEDED":
#                 print("  ✔ SQL executed successfully")
#                 return
#             elif state in ["FAILED", "CANCELED"]:
#                 raise Exception(f"SQL Failed: {sr.json()['status'].get('error', {})}")
#             elif time.time() - start > 300:
#                 raise Exception("SQL Execution Timed Out")
#             else:
#                 time.sleep(2)

#     def _load_json(self, path: str) -> dict:
#         with open(path, "r") as f:
#             return json.load(f)

#     def _save_json(self, data: dict) -> None:
#         with open(self.output_file, "w") as f:
#             json.dump(data, f, indent=2)


# # =============================================================================
# # PROGRAMMATIC ENTRY  (called by orchestrator.py)
# # =============================================================================

# def run_table_creation(
#     schema_path:   str,
#     workspace_url: str,
#     warehouse_id:  str,
#     token:         str,
#     catalog:       str,
#     schema_name:   str,
#     output_dir:    str  = ".",
#     auto_approve:  bool = False,
# ) -> tuple:
#     os.makedirs(output_dir, exist_ok=True)
#     status_path = os.path.join(output_dir, "table_creation_status.json")

#     agent = TableCreationAgent(schema_path, output_file=status_path)
#     agent.execute(
#         workspace_url=workspace_url,
#         warehouse_id=warehouse_id,
#         token=token,
#         catalog=catalog,
#         schema_name=schema_name,
#         auto_approve=auto_approve,
#     )

#     with open(status_path, "r") as f:
#         status = json.load(f)

#     return status, status_path


# # =============================================================================
# # STANDALONE CLI
# # =============================================================================

# if __name__ == "__main__":
#     schema_path = input("Enter Schema Output JSON path: ").strip()
#     agent = TableCreationAgent(schema_path)
#     agent.execute()


"""
TABLE/Table.py — Table Creation Agent
=======================================
Step 7 of the orchestration pipeline.

Approval layer for each table:
  - Shows the extracted table name (from schema file)
  - User picks: use as-is, enter a custom name, or skip
"""

import json
import os
import re
import requests
import time


# =============================================================================
# USER APPROVAL LAYER
# =============================================================================

def _approve_table(full_table_name: str, ddl: str) -> tuple:
    """
    Show the extracted table name and DDL preview,
    then let the user confirm, rename, or skip.

    Returns:
        (approved_table_name, approved_ddl)  — name chosen/entered by user
        (None, None)                          — if skipped
    """
    parts      = full_table_name.rsplit(".", 1)
    prefix     = parts[0] if len(parts) == 2 else ""

    print("\n" + "═" * 65)
    print("  TABLE NAME REVIEW")
    print("═" * 65)
    print(f"  Extracted name : {full_table_name}")
    print("─" * 65)
    print("\n  DDL Preview:")
    for line in ddl.splitlines():
        print(f"    {line}")
    print("═" * 65)

    while True:
        print("\n  Options:")
        print(f"    [1] Use extracted name  → {full_table_name}")
        print( "    [2] Enter a custom name")
        print( "    [S] Skip this table")

        choice = input("\n  Your choice [1 / 2 / S]: ").strip().upper()

        if choice == "1":
            print(f"  ✅ Using extracted name: {full_table_name}")
            return full_table_name, ddl

        elif choice == "2":
            custom = input(
                "  Enter your table name (table part only, not catalog/schema): "
            ).strip().lower().replace(" ", "_")

            if not custom:
                print("  ⚠  Name cannot be empty. Try again.")
                continue

            custom_full = f"{prefix}.{custom}" if prefix else custom
            new_ddl     = ddl.replace(full_table_name, custom_full, 1)
            print(f"  ✅ Using custom name: {custom_full}")
            return custom_full, new_ddl

        elif choice == "S":
            print(f"  ⏭  Skipped: {full_table_name}")
            return None, None

        else:
            print("  ⚠  Invalid choice. Enter 1, 2, or S.")


# =============================================================================
# TABLE CREATION AGENT
# =============================================================================

class TableCreationAgent:

    def __init__(self, schema_file: str, output_file: str = "table_creation_status.json"):
        self.schema_file = schema_file
        self.output_file = output_file

    def execute(
        self,
        workspace_url: str | None = None,
        warehouse_id:  str | None = None,
        token:         str | None = None,
        catalog:       str | None = None,
        schema_name:   str | None = None,
        auto_approve:  bool       = False,
    ):
        schema_data = self._load_json(self.schema_file)

        if not workspace_url:
            print("\n=== DESTINATION DETAILS ===")
            workspace_url = input("  Databricks Workspace URL        : ").strip().rstrip("/")
            warehouse_id  = input("  Databricks Warehouse ID         : ").strip()
            token         = input("  Databricks Personal Access Token: ").strip()
            catalog       = input("  Catalog name                    : ").strip()
            schema_name   = input("  Schema name                     : ").strip()

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/json",
        }

        results        = []
        created_tables = set()

        try:
            # ── Create catalog ────────────────────────────────────────
            print(f"\n  Creating catalog : {catalog}")
            self._execute_sql(
                workspace_url, warehouse_id, headers,
                f"CREATE CATALOG IF NOT EXISTS {catalog}",
            )

            # ── Create schema ─────────────────────────────────────────
            print(f"  Creating schema  : {catalog}.{schema_name}")
            self._execute_sql(
                workspace_url, warehouse_id, headers,
                f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema_name}",
            )

            # ── Process each table ────────────────────────────────────
            tables = schema_data.get("tables", [])
            print(f"\n  {len(tables)} table(s) found in schema file.")

            for idx, table in enumerate(tables, 1):
                raw_name     = table.get("table_name", f"table_{idx}")
                columns      = table.get("columns", [])
                partition_by = table.get("partition_by")

                table_part      = self._clean_name(raw_name)
                full_table_name = f"{catalog}.{schema_name}.{table_part}"

                if full_table_name in created_tables:
                    continue

                # Build DDL
                try:
                    ddl = self._build_ddl(full_table_name, columns, partition_by)
                except Exception as exc:
                    results.append({
                        "table_name": full_table_name,
                        "status":     "failed",
                        "error":      str(exc),
                    })
                    continue

                # ── APPROVAL ──────────────────────────────────────────
                if auto_approve:
                    approved_name = full_table_name
                    approved_ddl  = ddl
                else:
                    approved_name, approved_ddl = _approve_table(full_table_name, ddl)

                if approved_name is None:
                    results.append({
                        "table_name": full_table_name,
                        "status":     "skipped",
                    })
                    continue

                # ── Execute DDL ───────────────────────────────────────
                try:
                    self._execute_sql(workspace_url, warehouse_id, headers, approved_ddl)
                    results.append({
                        "table_name":          approved_name,
                        "original_table_name": full_table_name,
                        "status":              "created",
                    })
                    created_tables.add(approved_name)

                except Exception as exc:
                    results.append({
                        "table_name": approved_name,
                        "status":     "failed",
                        "error":      str(exc),
                    })

        except Exception as exc:
            print(f"\n❌ Fatal error: {exc}")

        # ── Save & print summary ──────────────────────────────────────
        final_output = {"catalog": catalog, "schema": schema_name, "tables": results}
        self._save_json(final_output)

        created = sum(1 for r in results if r["status"] == "created")
        skipped = sum(1 for r in results if r["status"] == "skipped")
        failed  = sum(1 for r in results if r["status"] == "failed")

        print("\n" + "=" * 65)
        print("  TABLE CREATION COMPLETE")
        print(f"  Created : {created}")
        print(f"  Skipped : {skipped}")
        print(f"  Failed  : {failed}")
        print("=" * 65)

    # ------------------------------------------------------------------
    def _build_ddl(self, full_table_name: str, columns: list, partition_by) -> str:
        if not columns:
            raise Exception(f"No columns defined for {full_table_name}")
        col_defs = [
            f"{c['name'].lower().replace(' ', '_')} {c['type'].upper()}"
            for c in columns
        ]
        ddl = (
            f"CREATE TABLE IF NOT EXISTS {full_table_name} (\n"
            f"    {',\n    '.join(col_defs)}\n"
            f")\nUSING DELTA"
        )
        if partition_by:
            parts = ", ".join(p.lower().replace(" ", "_") for p in partition_by)
            ddl  += f"\nPARTITIONED BY ({parts})"
        return ddl

    @staticmethod
    def _clean_name(raw_name: str) -> str:
        name = raw_name.split(".")[-1] if "." in raw_name else raw_name
        return name.replace(".csv", "").replace(" ", "_").lower()

    def _execute_sql(self, workspace_url, warehouse_id, headers, sql):
        response = requests.post(
            f"{workspace_url}/api/2.0/sql/statements",
            headers=headers,
            json={"statement": sql, "warehouse_id": warehouse_id},
        )
        if response.status_code != 200:
            raise Exception(f"SQL Submit Failed: {response.text}")

        stmt_id    = response.json()["statement_id"]
        status_url = f"{workspace_url}/api/2.0/sql/statements/{stmt_id}"
        start      = time.time()

        while True:
            sr    = requests.get(status_url, headers=headers)
            if sr.status_code != 200:
                raise Exception(f"Status Check Failed: {sr.text}")
            state = sr.json()["status"]["state"]

            if state == "SUCCEEDED":
                print("  ✔ SQL executed successfully")
                return
            elif state in ["FAILED", "CANCELED"]:
                raise Exception(f"SQL Failed: {sr.json()['status'].get('error', {})}")
            elif time.time() - start > 300:
                raise Exception("SQL Execution Timed Out")
            else:
                time.sleep(2)

    def _load_json(self, path: str) -> dict:
        with open(path, "r") as f:
            return json.load(f)

    def _save_json(self, data: dict) -> None:
        with open(self.output_file, "w") as f:
            json.dump(data, f, indent=2)


# =============================================================================
# PROGRAMMATIC ENTRY  (called by orchestrator.py)
# =============================================================================

def run_table_creation(
    schema_path:   str,
    workspace_url: str,
    warehouse_id:  str,
    token:         str,
    catalog:       str,
    schema_name:   str,
    output_dir:    str  = ".",
    auto_approve:  bool = False,
) -> tuple:
    os.makedirs(output_dir, exist_ok=True)
    status_path = os.path.join(output_dir, "table_creation_status.json")

    agent = TableCreationAgent(schema_path, output_file=status_path)
    agent.execute(
        workspace_url=workspace_url,
        warehouse_id=warehouse_id,
        token=token,
        catalog=catalog,
        schema_name=schema_name,
        auto_approve=auto_approve,
    )

    with open(status_path, "r") as f:
        status = json.load(f)

    return status, status_path


# =============================================================================
# STANDALONE CLI
# =============================================================================

if __name__ == "__main__":
    schema_path = input("Enter Schema Output JSON path: ").strip()
    agent = TableCreationAgent(schema_path)
    agent.execute()