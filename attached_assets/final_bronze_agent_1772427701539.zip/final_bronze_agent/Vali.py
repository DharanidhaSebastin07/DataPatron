# import json
# import os
# import requests
# import psycopg2
# import pyodbc
# import boto3


# # ============================================================
# # DRIVER DETECTOR
# # ============================================================

# def get_sql_driver():
#     """Detect best installed SQL Server ODBC driver automatically"""
#     drivers = pyodbc.drivers()

#     preferred_order = [
#         "ODBC Driver 18 for SQL Server",
#         "ODBC Driver 17 for SQL Server",
#         "ODBC Driver 13 for SQL Server",
#         "SQL Server"
#     ]

#     for d in preferred_order:
#         if d in drivers:
#             return d

#     raise Exception(
#         "No SQL Server ODBC driver installed. "
#         "Install Microsoft ODBC Driver 18 for SQL Server."
#     )


# # ============================================================
# # MAIN VALIDATION FUNCTION
# # ============================================================

# def validate_connections(json_file):
#     """Validate all pipeline connections in the given credentials JSON file."""

#     with open(json_file, "r") as f:
#         config = json.load(f)

#     results = []

#     for pipeline in config.get("pipelines", []):

#         source = pipeline["source_type"]
#         conn = pipeline["connection_template"]

#         print("\n" + "="*60)
#         print(f"Validating: {pipeline['pipeline_id']} ({source})")

#         try:
#             if source == "azure_sql":
#                 validate_azure_sql(conn)

#             elif source == "postgresql":
#                 validate_postgres(conn)

#             elif source == "s3":
#                 validate_s3(conn)

#             elif source == "rest_api":
#                 validate_api(conn)

#             print("Connection SUCCESS")
#             results.append({"pipeline_id": pipeline["pipeline_id"], "status": "success"})

#         except Exception as e:
#             print("Connection FAILED:", str(e))
#             results.append({"pipeline_id": pipeline["pipeline_id"], "status": "failed", "error": str(e)})

#     return results


# # ============================================================
# # PROGRAMMATIC ENTRY  (used by orchestrator)
# # ============================================================

# def run_validation(credentials_path: str, output_dir: str = ".") -> tuple:
#     """
#     Validate all connections and save results.

#     Args:
#         credentials_path: Path to credentials.json from cred.py.
#         output_dir:       Directory to save validation_results.json.

#     Returns:
#         Tuple of (results_list, credentials_path).
#         credentials_path is passed through so the next agent can use it.
#     """
#     results = validate_connections(credentials_path)

#     os.makedirs(output_dir, exist_ok=True)
#     results_path = os.path.join(output_dir, "validation_results.json")
#     with open(results_path, "w", encoding="utf-8") as f:
#         json.dump(results, f, indent=2)

#     print(f"\nValidation results saved: {results_path}")
#     return results, credentials_path


# # ============================================================
# # AZURE SQL VALIDATION
# # ============================================================

# def validate_azure_sql(conn):

#     driver = get_sql_driver()

#     connection_string = (
#         f"DRIVER={{{driver}}};"
#         f"SERVER={conn['server']};"
#         f"DATABASE={conn['database']};"
#         f"UID={conn['username']};"
#         f"PWD={conn['password']};"
#         "Encrypt=yes;"
#         "TrustServerCertificate=no;"
#         "Connection Timeout=30;"
#     )

#     connection = pyodbc.connect(connection_string)
#     connection.close()


# # ============================================================
# # POSTGRES VALIDATION
# # ============================================================

# def validate_postgres(conn):

#     connection = psycopg2.connect(
#         host=conn["host"],
#         port=conn["port"],
#         database=conn["database"],
#         user=conn["username"],
#         password=conn["password"]
#     )
#     connection.close()


# # ============================================================
# # S3 VALIDATION
# # ============================================================

# def validate_s3(conn):

#     s3 = boto3.client(
#         "s3",
#         aws_access_key_id=conn["aws_access_key_id"],
#         aws_secret_access_key=conn["aws_secret_access_key"],
#         region_name=conn["region"]
#     )

#     s3.head_bucket(Bucket=conn["bucket"])


# # ============================================================
# # REST API VALIDATION
# # ============================================================

# def validate_api(conn):

#     headers = {}

#     if conn.get("auth_type") == "api_key":
#         headers["Authorization"] = conn["api_key"]

#     response = requests.get(conn["endpoint"], headers=headers, timeout=10)

#     if response.status_code >= 400:
#         raise Exception(f"API returned status {response.status_code}")


# # ============================================================
# # RUN  (standalone CLI)
# # ============================================================

# if __name__ == "__main__":

#     file_path = input("Enter credential JSON file: ").strip()
#     run_validation(file_path)


import json
import os
import requests
import psycopg2
import pyodbc
import boto3


# ============================================================
# DRIVER DETECTOR
# ============================================================

def get_sql_driver():
    """Detect best installed SQL Server ODBC driver automatically"""
    drivers = pyodbc.drivers()

    preferred_order = [
        "ODBC Driver 18 for SQL Server",
        "ODBC Driver 17 for SQL Server",
        "ODBC Driver 13 for SQL Server",
        "SQL Server"
    ]

    for d in preferred_order:
        if d in drivers:
            return d

    raise Exception(
        "No SQL Server ODBC driver installed. "
        "Install Microsoft ODBC Driver 18 for SQL Server."
    )


# ============================================================
# MAIN VALIDATION FUNCTION
# ============================================================

def validate_connections(json_file):
    """Validate all pipeline connections in the given credentials JSON file."""

    with open(json_file, "r") as f:
        config = json.load(f)

    results = []

    for pipeline in config.get("pipelines", []):

        source = pipeline["source_type"]
        conn = pipeline["connection_template"]

        print("\n" + "="*60)
        print(f"Validating: {pipeline['pipeline_id']} ({source})")

        try:
            if source == "azure_sql":
                validate_azure_sql(conn)

            elif source == "postgresql":
                validate_postgres(conn)

            elif source == "s3":
                validate_s3(conn)

            elif source == "rest_api":
                validate_api(conn)

            print("Connection SUCCESS")
            results.append({"pipeline_id": pipeline["pipeline_id"], "status": "success"})

        except Exception as e:
            print("Connection FAILED:", str(e))
            results.append({"pipeline_id": pipeline["pipeline_id"], "status": "failed", "error": str(e)})

    return results


# ============================================================
# PROGRAMMATIC ENTRY  (used by orchestrator)
# ============================================================

def run_validation(credentials_path: str, output_dir: str = ".") -> tuple:
    """
    Validate all connections and save results.

    Args:
        credentials_path: Path to credentials.json from cred.py.
        output_dir:       Directory to save validation_results.json.

    Returns:
        Tuple of (results_list, credentials_path).
        credentials_path is passed through so the next agent can use it.
    """
    results = validate_connections(credentials_path)

    os.makedirs(output_dir, exist_ok=True)
    results_path = os.path.join(output_dir, "validation_results.json")
    with open(results_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"\nValidation results saved: {results_path}")
    return results, credentials_path


# ============================================================
# AZURE SQL VALIDATION
# ============================================================

def validate_azure_sql(conn):

    driver = get_sql_driver()

    # Modern drivers (ODBC 17/18) support Encrypt + TrustServerCertificate=no.
    # The legacy "SQL Server" driver doesn't support these attributes and will
    # throw an SSL/invalid-attribute error, so we fall back gracefully.
    LEGACY_DRIVERS = {"SQL Server"}

    if driver in LEGACY_DRIVERS:
        # Legacy driver: omit Encrypt/TrustServerCertificate attributes
        connection_string = (
            f"DRIVER={{{driver}}};"
            f"SERVER={conn['server']};"
            f"DATABASE={conn['database']};"
            f"UID={conn['username']};"
            f"PWD={conn['password']};"
            "Connection Timeout=30;"
        )
    else:
        connection_string = (
            f"DRIVER={{{driver}}};"
            f"SERVER={conn['server']};"
            f"DATABASE={conn['database']};"
            f"UID={conn['username']};"
            f"PWD={conn['password']};"
            "Encrypt=yes;"
            "TrustServerCertificate=no;"
            "Connection Timeout=30;"
        )

    connection = pyodbc.connect(connection_string)
    connection.close()


# ============================================================
# POSTGRES VALIDATION
# ============================================================

def validate_postgres(conn):

    connection = psycopg2.connect(
        host=conn["host"],
        port=conn["port"],
        database=conn["database"],
        user=conn["username"],
        password=conn["password"]
    )
    connection.close()


# ============================================================
# S3 VALIDATION
# ============================================================

def validate_s3(conn):

    s3 = boto3.client(
        "s3",
        aws_access_key_id=conn["aws_access_key_id"],
        aws_secret_access_key=conn["aws_secret_access_key"],
        region_name=conn["region"]
    )

    s3.head_bucket(Bucket=conn["bucket"])


# ============================================================
# REST API VALIDATION
# ============================================================

def validate_api(conn):

    headers = {}

    if conn.get("auth_type") == "api_key":
        headers["Authorization"] = conn["api_key"]

    response = requests.get(conn["endpoint"], headers=headers, timeout=10)

    if response.status_code >= 400:
        raise Exception(f"API returned status {response.status_code}")


# ============================================================
# RUN  (standalone CLI)
# ============================================================

if __name__ == "__main__":

    file_path = input("Enter credential JSON file: ").strip()
    run_validation(file_path)