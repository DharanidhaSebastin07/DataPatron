
import json
import os


# ------------------------------------------------------------
# PROGRAMMATIC ENTRY  (used by orchestrator)
# ------------------------------------------------------------

def run_migration_plan(
    credentials_path: str,
    table_creation_path: str,
    strategy_path: str,
    output_dir: str = ".",
) -> tuple:
    """
    Generate the final migration plan JSON from upstream artefacts.

    Args:
        credentials_path:    Path to credentials.json.
        table_creation_path: Path to table_creation_status.json.
        strategy_path:       Path to strategy.json.
        output_dir:          Directory to save migration_plan.json.

    Returns:
        Tuple of (migration_plan_dict, migration_plan_filepath).
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "migration_plan.json")

    cred          = load_json(credentials_path)
    table_creation = load_json(table_creation_path)
    strategy      = load_json(strategy_path)

    result = generate_migration_plan(cred, table_creation, strategy)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print("\n✅ Migration plan generated successfully")
    print("Saved to:", output_path)

    return result, output_path

# -----------------------------
# LOAD JSON SAFE
# -----------------------------
def load_json(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

# -----------------------------
# FORMAT TARGET TABLE NAME
# -----------------------------
def format_table_name(name):
    name=name.lower()
    if name.endswith(".csv"):
        name=name[:-4]
    return name.replace(" ","_")

# -----------------------------
# GENERATE PLAN
# -----------------------------
def generate_migration_plan(cred,table_creation,strategy):

    session_id=cred["session_id"]
    catalog=table_creation["catalog"]
    schema=table_creation["schema"]

    final_pipelines=[]

    for cred_pipeline in cred["pipelines"]:

        pipeline_id=cred_pipeline["pipeline_id"]
        source_type=cred_pipeline["source_type"]

        strategy_pipeline=next(
            (p for p in strategy["pipelines"]
             if p["pipeline_id"]==pipeline_id),
            None
        )

        if not strategy_pipeline:
            print(f"⚠ Strategy missing for pipeline {pipeline_id}")
            continue

        # SUPPORT BOTH connection_template OR connection
        ct = (
            cred_pipeline.get("connection_template")
            or cred_pipeline.get("connection")
            or {}
        )

        # =====================================================
        # S3 SUPPORT (NEW AWS FIELD NAMES HANDLED HERE)
        # =====================================================
        if source_type=="s3":

            source_block={

                "source_type":"s3",
                "engine":cred_pipeline.get("execution_engine","spark"),

                # Map BOTH old + new AWS field names
                "connection":{

                    "access_key":
                        ct.get("aws_access_key_id")
                        or ct.get("access_key"),

                    "secret_key":
                        ct.get("aws_secret_access_key")
                        or ct.get("secret_key"),

                    "region":
                        ct.get("region","us-east-1")
                },

                "location":{
                    "bucket":ct.get("bucket"),

                    # prefix → base_path mapping
                    "base_path":
                        ct.get("prefix")
                        or ct.get("base_path","")
                },

                "file_format":
                    ct.get("file_format","csv")
            }

        # =====================================================
        # AZURE SQL
        # =====================================================
        elif source_type=="azure_sql":

            source_block={

                "source_type":"azure_sql",
                "engine":cred_pipeline.get("execution_engine","spark"),

                "connection":{
                    "host":ct.get("server"),
                    "database":ct.get("database"),
                    "user":ct.get("username"),
                    "password":ct.get("password")
                },

                "schema":ct.get("schema","dbo")
            }

        else:
            raise ValueError(f"Unsupported source type {source_type}")

        # =====================================================
        # TABLES BLOCK
        # =====================================================
        tables_block=[]

        for table in strategy_pipeline["tables"]:

            src=table["table_name"]

            if source_type=="s3":
                tgt_name=format_table_name(src)
            else:
                tgt_name=src.split(".")[-1].lower()

            target=f"{catalog}.{schema}.{tgt_name}"

            tables_block.append({
                "source_name":src,
                "target_table":target,
                "write_strategy":table.get("write_strategy","append"),
                "load_type":"incremental"
                    if table.get("watermark_column") else "full",
                "watermark_column":table.get("watermark_column"),
                "partition_by":table.get("partition_by"),
                "parallelism":table.get("parallelism",1)
            })

        final_pipelines.append({
            "pipeline_id":pipeline_id,
            "source":source_block,
            "tables":tables_block
        })

    # -----------------------------
    # FINAL OUTPUT
    # -----------------------------
    return {
        "session_id":session_id,
        "migration_plan":{
            "target":{
                "catalog":catalog,
                "schema":schema
            },
            "pipelines":final_pipelines
        }
    }


# ======================================================
# MAIN
# ======================================================
if __name__=="__main__":

    print("\n=== Migration Plan Generator ===\n")

    cred_path=input("Credential JSON: ").strip()
    table_path=input("Table Creation JSON: ").strip()
    strategy_path=input("Strategy JSON: ").strip()
    output_path=input("Output JSON: ").strip()

    cred=load_json(cred_path)
    table_creation=load_json(table_path)
    strategy=load_json(strategy_path)

    result=generate_migration_plan(
        cred,table_creation,strategy
    )

    with open(output_path,"w",encoding="utf-8") as f:
        json.dump(result,f,indent=2)

    print("\n✅ Migration plan generated successfully")
    print("Saved to:",output_path)