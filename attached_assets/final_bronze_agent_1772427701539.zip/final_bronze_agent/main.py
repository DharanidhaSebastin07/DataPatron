"""
main.py — Bronze Ingestion Platform Entry Point
================================================
Run this file to start everything:

    python main.py

Project structure:
    project/
    ├── main.py              ← YOU ARE HERE
    ├── MCA/                 ← Step 1: parse request, build pipeline plan
    │   ├── __init__.py
    │   ├── orchestrator.py
    │   ├── new_mca.py
    │   ├── llm.py
    │   ├── s3.py
    │   ├── sql.py
    │   ├── pg.py
    │   └── rest_handler.py
    ├── CRED/                ← Step 2: collect source credentials
    │   └── cred.py
    ├── VALI/                ← Step 3: validate connections
    │   └── vali.py
    ├── METADATA/            ← Step 4: extract metadata
    │   └── metadata.py
    ├── PIPELINE/            ← Step 5: build pipeline strategy
    │   └── pipeline.py
    ├── SCHEMA/              ← Step 6: map schemas
    │   └── schema.py
    ├── TABLE/               ← Step 7: create Databricks tables
    │   └── Table.py
    └── FINAL_GEN/           ← Step 8: generate migration plan
        └── final_gen.py
"""

import sys
import os

# Project root = folder that contains main.py
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Expose root to orchestrator via environment variable
os.environ["BRONZE_ROOT_DIR"] = ROOT_DIR

# Add MCA/ to sys.path so orchestrator is importable
sys.path.insert(0, os.path.join(ROOT_DIR, "MCA"))

from orchestrator import run_pipeline

if __name__ == "__main__":
    try:
        run_pipeline()
    except KeyboardInterrupt:
        print("\n\nCancelled by user.")
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        sys.exit(1)