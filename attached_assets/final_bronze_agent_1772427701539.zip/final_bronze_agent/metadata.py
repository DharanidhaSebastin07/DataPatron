import json
import os
import boto3
import requests
import pyodbc
import pandas as pd
import io


# ------------------------------------------------------------
# DRIVER DETECTION (ROBUST)
# ------------------------------------------------------------

def get_sql_driver():
    drivers = pyodbc.drivers()
    for d in drivers:
        if "SQL Server" in d:
            return d
    raise Exception(f"No SQL Server ODBC driver found. Installed drivers: {drivers}")


# ------------------------------------------------------------
# AZURE SQL SAMPLE EXTRACTION (ALL TABLES)
# ------------------------------------------------------------

def extract_azure_samples(conn):

    driver = get_sql_driver()

    connection_string = (
        f"DRIVER={{{driver}}};"
        f"SERVER={conn['server']};"
        f"DATABASE={conn['database']};"
        f"UID={conn['username']};"
        f"PWD={conn['password']};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
    )

    connection = pyodbc.connect(connection_string, timeout=10)
    cursor = connection.cursor()

    schema = conn.get("schema") or "dbo"

    cursor.execute("""
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ?
    """, schema)

    tables = [row[0] for row in cursor.fetchall()]

    if not tables:
        raise Exception(f"No tables found in schema: {schema}")

    samples = {}

    for table in tables:
        query = f"SELECT TOP 5 * FROM {schema}.{table}"
        df = pd.read_sql(query, connection)
        samples[f"{schema}.{table}"] = df.to_dict(orient="records")

    connection.close()
    return samples


# ------------------------------------------------------------
# S3 SAMPLE EXTRACTION
# ------------------------------------------------------------

def extract_s3_samples(conn):

    s3 = boto3.client(
        "s3",
        aws_access_key_id=conn["aws_access_key_id"],
        aws_secret_access_key=conn["aws_secret_access_key"],
        region_name=conn["region"]
    )

    response = s3.list_objects_v2(
        Bucket=conn["bucket"],
        Prefix=conn.get("prefix", "")
    )

    samples = {}

    for obj in response.get("Contents", []):
        key = obj["Key"]

        data = s3.get_object(Bucket=conn["bucket"], Key=key)["Body"].read()

        if conn.get("file_format") == "json":
            df = pd.read_json(io.BytesIO(data))
        elif conn.get("file_format") == "parquet":
            df = pd.read_parquet(io.BytesIO(data))
        else:
            df = pd.read_csv(io.BytesIO(data))

        samples[key] = df.head(5).to_dict(orient="records")

    return samples


# ------------------------------------------------------------
# REST API SAMPLE EXTRACTION
# ------------------------------------------------------------

def extract_api_samples(conn):

    headers = {}

    if conn.get("auth_type") == "api_key":
        headers["Authorization"] = conn["api_key"]

    response = requests.get(conn["endpoint"], headers=headers)
    data = response.json()

    if isinstance(data, list):
        return data[:5]

    return data


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

def create_metadata_file(input_json, output_metadata="metadata.json"):

    with open(input_json, "r") as f:
        config = json.load(f)

    metadata = {"sources": []}

    for pipeline in config["pipelines"]:

        source = pipeline["source_type"]
        conn = pipeline["connection_template"]

        print(f"Extracting metadata for {source}")

        source_entry = {"source_type": source}

        try:
            if source == "azure_sql":
                source_entry["sample_data"] = extract_azure_samples(conn)

            elif source == "s3":
                source_entry["sample_data"] = extract_s3_samples(conn)

            elif source == "rest_api":
                source_entry["sample_data"] = extract_api_samples(conn)

        except Exception as e:
            source_entry["error"] = str(e)
            print(f"Metadata extraction failed for {source}: {e}")

        metadata["sources"].append(source_entry)

    with open(output_metadata, "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"Metadata saved to {output_metadata}")


# ------------------------------------------------------------
# PROGRAMMATIC ENTRY  (used by orchestrator)
# ------------------------------------------------------------

def run_metadata(credentials_path: str, output_dir: str = ".") -> tuple:
    """
    Extract metadata from all sources and save to metadata.json.

    Args:
        credentials_path: Path to credentials.json.
        output_dir:       Directory to save metadata.json.

    Returns:
        Tuple of (metadata_dict, metadata_filepath).
    """
    metadata_path = os.path.join(output_dir, "metadata.json")
    os.makedirs(output_dir, exist_ok=True)
    create_metadata_file(credentials_path, metadata_path)

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    return metadata, metadata_path


# ------------------------------------------------------------
# RUN  (standalone CLI)
# ------------------------------------------------------------

if __name__ == "__main__":
    file_path = input("Enter credential JSON path: ").strip()
    run_metadata(file_path)

import json
import os
import boto3
import requests
import pyodbc
import pandas as pd
import io


# ------------------------------------------------------------
# DRIVER DETECTION
# ------------------------------------------------------------
def get_sql_driver():
    drivers = pyodbc.drivers()
    for d in drivers:
        if "SQL Server" in d:
            return d
    raise Exception(f"No SQL Server ODBC driver found. Installed drivers: {drivers}")


# ------------------------------------------------------------
# AZURE SQL SAMPLE EXTRACTION
# ------------------------------------------------------------
def extract_azure_samples(conn):

    driver = get_sql_driver()

    connection_string = (
        f"DRIVER={{{driver}}};"
        f"SERVER={conn['server']};"
        f"DATABASE={conn['database']};"
        f"UID={conn['username']};"
        f"PWD={conn['password']};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
    )

    connection = pyodbc.connect(connection_string, timeout=10)
    cursor = connection.cursor()

    schema = conn.get("schema") or "dbo"

    cursor.execute("""
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ?
    """, schema)

    tables = [row[0] for row in cursor.fetchall()]

    if not tables:
        raise Exception(f"No tables found in schema: {schema}")

    samples = {}

    for table in tables:
        query = f"SELECT TOP 5 * FROM {schema}.{table}"
        df = pd.read_sql(query, connection)
        samples[f"{schema}.{table}"] = df.to_dict(orient="records")

    connection.close()
    return samples


# ------------------------------------------------------------
# S3 SAMPLE EXTRACTION
# ------------------------------------------------------------
def extract_s3_samples(conn):

    s3 = boto3.client(
        "s3",
        aws_access_key_id=conn["aws_access_key_id"],
        aws_secret_access_key=conn["aws_secret_access_key"],
        region_name=conn["region"]
    )

    response = s3.list_objects_v2(
        Bucket=conn["bucket"],
        Prefix=conn.get("prefix", "")
    )

    samples = {}

    for obj in response.get("Contents", []):
        key = obj["Key"]

        data = s3.get_object(Bucket=conn["bucket"], Key=key)["Body"].read()

        if conn.get("file_format") == "json":
            df = pd.read_json(io.BytesIO(data))
        elif conn.get("file_format") == "parquet":
            df = pd.read_parquet(io.BytesIO(data))
        else:
            df = pd.read_csv(io.BytesIO(data))

        samples[key] = df.head(5).to_dict(orient="records")

    return samples


# ------------------------------------------------------------
# REST API SAMPLE EXTRACTION  (FIXED FOR NGROK + STREAMING)
# ------------------------------------------------------------
def extract_api_samples(conn):

    endpoint = conn["endpoint"]

    # ⭐ your API NEEDS query param api_key
    params = {
        "api_key": conn["api_key"],
        "n": conn.get("sample_n", 5)
    }

    try:
        response = requests.get(endpoint, params=params, timeout=20)
    except Exception as e:
        raise Exception(f"API connection failed: {e}")

    # -----------------------------
    # NGROK sometimes returns HTML
    # -----------------------------
    content_type = response.headers.get("Content-Type", "")

    if "application/json" not in content_type:
        raise Exception(
            "API did not return JSON\n"
            f"Status={response.status_code}\n"
            f"Preview:\n{response.text[:400]}"
        )

    try:
        data = response.json()
    except Exception:
        raise Exception("JSON parsing failed:\n" + response.text[:400])

    # -----------------------------
    # normalize into table structure
    # -----------------------------
    if isinstance(data, list):
        return {"api_result": data[:5]}

    if isinstance(data, dict):
        return {"api_result": [data]}

    return {"api_result": []}


# ------------------------------------------------------------
# MAIN METADATA BUILDER
# ------------------------------------------------------------
def create_metadata_file(input_json, output_metadata="metadata.json"):

    with open(input_json, "r") as f:
        config = json.load(f)

    metadata = {"sources": []}

    for pipeline in config["pipelines"]:

        source = pipeline["source_type"]
        conn = pipeline["connection_template"]

        print(f"\nExtracting metadata for {source}")

        source_entry = {"source_type": source}

        try:
            if source == "azure_sql":
                source_entry["sample_data"] = extract_azure_samples(conn)

            elif source == "s3":
                source_entry["sample_data"] = extract_s3_samples(conn)

            elif source in ["rest_api", "api"]:
                source_entry["sample_data"] = extract_api_samples(conn)

        except Exception as e:
            source_entry["error"] = str(e)
            print(f"Metadata extraction failed for {source}: {e}")

        metadata["sources"].append(source_entry)

    with open(output_metadata, "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"\nMetadata saved to {output_metadata}")


# ------------------------------------------------------------
# PROGRAMMATIC ENTRY
# ------------------------------------------------------------
def run_metadata(credentials_path: str, output_dir: str = "."):

    metadata_path = os.path.join(output_dir, "metadata.json")
    os.makedirs(output_dir, exist_ok=True)

    create_metadata_file(credentials_path, metadata_path)

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    return metadata, metadata_path


# ------------------------------------------------------------
# CLI RUN
# ------------------------------------------------------------
if __name__ == "__main__":
    file_path = input("Enter credential JSON path: ").strip()
    run_metadata(file_path)