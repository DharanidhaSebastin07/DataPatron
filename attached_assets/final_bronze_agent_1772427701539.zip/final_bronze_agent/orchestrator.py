# """
# MCA/orchestrator.py — Bronze Ingestion Platform Orchestrator
# =============================================================
# Called by main.py. Navigates into each agent folder in sequence
# and imports the agent from there.

# Step 1  → MCA/         new_mca.py
# Step 2  → CRED/        cred.py
# Step 3  → VALI/        vali.py
# Step 4  → METADATA/    metadata.py
# Step 5  → PIPELINE/    pipeline.py
# Step 6  → SCHEMA/      schema.py
# Step 7  → TABLE/       Table.py
# Step 8  → FINAL_GEN/   final_gen.py
# """

# import json
# import logging
# import os
# import sys
# from datetime import datetime

# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
#     datefmt="%Y-%m-%d %H:%M:%S",
# )
# logger = logging.getLogger("Orchestrator")


# def _add(folder: str) -> None:
#     """Add a folder to sys.path if not already present."""
#     if folder not in sys.path:
#         sys.path.insert(0, folder)


# # =============================================================================
# # DATABRICKS SESSION CONFIG — collected once, saved for future runs
# # =============================================================================

# def load_session_config(config_path: str) -> dict:
#     if os.path.exists(config_path):
#         logger.info("Loading session config from: %s", config_path)
#         with open(config_path, "r", encoding="utf-8") as f:
#             return json.load(f)

#     print("\n" + "=" * 60)
#     print("  DATABRICKS DESTINATION SETUP")
#     print("  (saved to session_config.json — won't be asked again)")
#     print("=" * 60)

#     config = {
#         "databricks_workspace_url": input("  Databricks workspace URL : ").strip().rstrip("/"),
#         "databricks_warehouse_id":  input("  SQL Warehouse ID         : ").strip(),
#         "databricks_token":         input("  Personal Access Token    : ").strip(),
#         "catalog":                  input("  Target catalog name      : ").strip(),
#         "schema":                   input("  Target schema name       : ").strip(),
#     }

#     with open(config_path, "w", encoding="utf-8") as f:
#         json.dump(config, f, indent=2)

#     logger.info("Session config saved: %s", config_path)
#     return config


# # =============================================================================
# # ORCHESTRATOR
# # =============================================================================

# def run_pipeline() -> dict:
#     """
#     Run all 8 agents in sequence, importing each from its own folder.
#     Root directory is read from the BRONZE_ROOT_DIR environment variable
#     set by main.py.
#     """

#     # Get root dir — set by main.py via os.environ before importing this module
#     root_dir = os.environ.get("BRONZE_ROOT_DIR")
#     if not root_dir:
#         # Fallback: infer root as one level above MCA/
#         root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#     # Resolve each agent folder
#     mca_dir      = os.path.join(root_dir, "MCA")
#     cred_dir     = os.path.join(root_dir, "CRED")
#     vali_dir     = os.path.join(root_dir, "VALI")
#     metadata_dir = os.path.join(root_dir, "METADATA")
#     pipeline_dir = os.path.join(root_dir, "PIPELINE")
#     schema_dir   = os.path.join(root_dir, "SCHEMA")
#     table_dir    = os.path.join(root_dir, "TABLE")
#     final_dir    = os.path.join(root_dir, "FINAL_GEN")

#     timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
#     output_dir = os.path.join(root_dir, "session_output", f"run_{timestamp}")
#     os.makedirs(output_dir, exist_ok=True)

#     config_path = os.path.join(root_dir, "session_output", "session_config.json")
#     os.makedirs(os.path.dirname(config_path), exist_ok=True)

#     artefacts: dict = {}

#     print("\n" + "=" * 60)
#     print("  BRONZE INGESTION PLATFORM — ORCHESTRATOR")
#     print(f"  Output: {os.path.abspath(output_dir)}")
#     print("=" * 60)

#     # ── STEP 1 — MCA/ ─────────────────────────────────────────────────────────
#     print("\n▶  STEP 1/8 — Master Control Agent  [MCA/]")
#     print("-" * 60)

#     _add(mca_dir)
#     from new_mca import MasterControlAgent

#     user_input         = input("  Describe your ingestion request:\n  > ").strip()
#     mca                = MasterControlAgent()
#     mca_plan, mca_path = mca.execute(user_input, output_dir=output_dir)

#     artefacts["mca_plan"] = mca_path
#     logger.info("MCA plan → %s", mca_path)

#     # ── STEP 2 — CRED/ ────────────────────────────────────────────────────────
#     print("\n▶  STEP 2/8 — Credentials Collection  [CRED/]")
#     print("-" * 60)

#     _add(cred_dir)
#     from cred import CredentialsCollectionAgent

#     cred_agent   = CredentialsCollectionAgent()
#     _, cred_path = cred_agent.execute(source=mca_plan, output_dir=output_dir)

#     artefacts["credentials"] = cred_path
#     logger.info("Credentials → %s", cred_path)

#     # ── STEP 3 — VALI/ ────────────────────────────────────────────────────────
#     print("\n▶  STEP 3/8 — Connection Validation  [VALI/]")
#     print("-" * 60)

#     _add(vali_dir)
#     from vali import run_validation

#     run_validation(cred_path, output_dir=output_dir)
#     artefacts["validation"] = os.path.join(output_dir, "validation_results.json")
#     logger.info("Validation → %s", artefacts["validation"])

#     # ── STEP 4 — METADATA/ ────────────────────────────────────────────────────
#     print("\n▶  STEP 4/8 — Metadata Extraction  [METADATA/]")
#     print("-" * 60)

#     _add(metadata_dir)
#     from metadata import run_metadata

#     _, metadata_path      = run_metadata(cred_path, output_dir=output_dir)
#     artefacts["metadata"] = metadata_path
#     logger.info("Metadata → %s", metadata_path)

#     # ── STEP 5 — PIPELINE/ ────────────────────────────────────────────────────
#     print("\n▶  STEP 5/8 — Pipeline Strategy  [PIPELINE/]")
#     print("-" * 60)

#     _add(pipeline_dir)
#     from pipeline import run_pipeline_strategy

#     _, strategy_path      = run_pipeline_strategy(
#         mca_path=cred_path,
#         metadata_path=metadata_path,
#         output_dir=output_dir,
#     )
#     artefacts["strategy"] = strategy_path
#     logger.info("Strategy → %s", strategy_path)

#     # ── STEP 6 — SCHEMA/ ──────────────────────────────────────────────────────
#     print("\n▶  STEP 6/8 — Schema Mapping  [SCHEMA/]")
#     print("-" * 60)

#     _add(schema_dir)
#     from schema import run_schema_mapping

#     _, schema_path      = run_schema_mapping(
#         strategy_path=strategy_path,
#         metadata_path=metadata_path,
#         output_dir=output_dir,
#     )
#     artefacts["schema"] = schema_path
#     logger.info("Schema → %s", schema_path)

#     # ── STEP 7 — TABLE/ ───────────────────────────────────────────────────────
#     print("\n▶  STEP 7/8 — Table Creation  [TABLE/]")
#     print("-" * 60)

#     _add(table_dir)
#     from table import run_table_creation

#     db_config     = load_session_config(config_path)
#     _, table_path = run_table_creation(
#         schema_path=schema_path,
#         workspace_url=db_config["databricks_workspace_url"],
#         warehouse_id=db_config["databricks_warehouse_id"],
#         token=db_config["databricks_token"],
#         catalog=db_config["catalog"],
#         schema_name=db_config["schema"],
#         output_dir=output_dir,
#     )
#     artefacts["table_creation"] = table_path
#     logger.info("Table creation → %s", table_path)

#     # ── STEP 8 — FINAL_GEN/ ───────────────────────────────────────────────────
#     print("\n▶  STEP 8/8 — Migration Plan Generator  [FINAL_GEN/]")
#     print("-" * 60)

#     _add(final_dir)
#     from final_gen import run_migration_plan

#     _, migration_path           = run_migration_plan(
#         credentials_path=cred_path,
#         table_creation_path=table_path,
#         strategy_path=strategy_path,
#         output_dir=output_dir,
#     )
#     artefacts["migration_plan"] = migration_path
#     logger.info("Migration plan → %s", migration_path)

#     # ── SUMMARY ───────────────────────────────────────────────────────────────
#     print("\n" + "=" * 60)
#     print("  ✅  ALL STEPS COMPLETE")
#     print("=" * 60)
#     print(f"\n  Output : {os.path.abspath(output_dir)}\n")
#     print("  Artefacts:")
#     for name, path in artefacts.items():
#         print(f"    {name:<20} → {path}")
#     print(f"\n  NEXT: Upload '{migration_path}' to Databricks and run execution.py\n")

#     manifest_path = os.path.join(output_dir, f"manifest_{timestamp}.json")
#     with open(manifest_path, "w", encoding="utf-8") as f:
#         json.dump(artefacts, f, indent=2)
#     logger.info("Manifest → %s", manifest_path)

#     return artefacts


"""
MCA/orchestrator.py — Bronze Ingestion Platform Orchestrator
=============================================================
Called by main.py. Loads each agent by absolute file path using
importlib — immune to sys.path ordering and module name collisions.

Step 1  → MCA/         new_mca.py
Step 2  → CRED/        cred.py
Step 3  → VALI/        vali.py
Step 4  → METADATA/    metadata.py
Step 5  → PIPELINE/    pipeline.py
Step 6  → SCHEMA/      schema.py
Step 7  → TABLE/       Table.py
Step 8  → FINAL_GEN/   final_gen.py
"""

import json
import logging
import os
import sys
import importlib.util
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("Orchestrator")


# =============================================================================
# IMPORTLIB LOADER — loads any agent by absolute path, no sys.path needed
# =============================================================================

def _load(module_name: str, file_path: str):
    """
    Import a module from an absolute file path.
    The module_name is a unique alias — prevents cache collisions between
    files with the same name in different folders (e.g. MCA/s3.py vs CRED/s3.py).
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(
            f"Agent file not found: {file_path}\n"
            f"Make sure '{os.path.basename(file_path)}' is inside '{os.path.dirname(file_path)}/'"
        )
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# =============================================================================
# DATABRICKS SESSION CONFIG — collected once, saved for future runs
# =============================================================================

def load_session_config(config_path: str) -> dict:
    if os.path.exists(config_path):
        logger.info("Loading session config from: %s", config_path)
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)

    print("\n" + "=" * 60)
    print("  DATABRICKS DESTINATION SETUP")
    print("  (saved to session_config.json — won't be asked again)")
    print("=" * 60)

    config = {
        "databricks_workspace_url": input("  Databricks workspace URL : ").strip().rstrip("/"),
        "databricks_warehouse_id":  input("  SQL Warehouse ID         : ").strip(),
        "databricks_token":         input("  Personal Access Token    : ").strip(),
        "catalog":                  input("  Target catalog name      : ").strip(),
        "schema":                   input("  Target schema name       : ").strip(),
    }

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    logger.info("Session config saved: %s", config_path)
    return config


# =============================================================================
# ORCHESTRATOR
# =============================================================================

def run_pipeline() -> dict:
    """
    Run all 8 agents in sequence.
    Root directory is read from the BRONZE_ROOT_DIR env var set by main.py.
    """

    root_dir = os.environ.get("BRONZE_ROOT_DIR")
    if not root_dir:
        # Fallback: infer root as one level above MCA/
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # Absolute paths for every agent file
    agents = {
        "new_mca":   os.path.join(root_dir, "MCA","new_mca.py"),
        "cred":      os.path.join(root_dir, "CRED","cred.py"),
        "vali":      os.path.join(root_dir, "Vali.py"),
        "metadata": os.path.join(root_dir, "metadata.py"),
        "pipeline":  os.path.join(root_dir, "pipeline.py"),
        "schema":    os.path.join(root_dir,"schema.py"),
        "Table":     os.path.join(root_dir,"Table.py"),
        "final_gen": os.path.join(root_dir,"final_gen.py"),
    }

    # MCA/ must be on sys.path so new_mca.py can import llm.py, s3.py etc.
    mca_dir = os.path.join(root_dir, "MCA")
    if mca_dir not in sys.path:
        sys.path.insert(0, mca_dir)

    timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(root_dir, "session_output", f"run_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)

    config_path = os.path.join(root_dir, "session_output", "session_config.json")
    os.makedirs(os.path.dirname(config_path), exist_ok=True)

    artefacts: dict = {}

    print("\n" + "=" * 60)
    print("  BRONZE INGESTION PLATFORM — ORCHESTRATOR")
    print(f"  Output: {os.path.abspath(output_dir)}")
    print("=" * 60)

    # ── STEP 1 — MCA/ ─────────────────────────────────────────────────────────
    print("\n▶  STEP 1/8 — Master Control Agent  [MCA/]")
    print("-" * 60)

    mca_mod            = _load("agent_mca", agents["new_mca"])
    user_input         = input("  Describe your ingestion request:\n  > ").strip()
    mca                = mca_mod.MasterControlAgent()
    mca_plan, mca_path = mca.execute(user_input, output_dir=output_dir)

    artefacts["mca_plan"] = mca_path
    logger.info("MCA plan → %s", mca_path)

    # ── STEP 2 — CRED/ ────────────────────────────────────────────────────────
    print("\n▶  STEP 2/8 — Credentials Collection  [CRED/]")
    print("-" * 60)

    cred_mod     = _load("agent_cred", agents["cred"])
    cred_agent   = cred_mod.CredentialsCollectionAgent()
    _, cred_path = cred_agent.execute(source=mca_plan, output_dir=output_dir)

    artefacts["credentials"] = cred_path
    logger.info("Credentials → %s", cred_path)

    # ── STEP 3 — VALI/ ────────────────────────────────────────────────────────
    print("\n▶  STEP 3/8 — Connection Validation  [VALI/]")
    print("-" * 60)

    vali_mod = _load("agent_vali", agents["vali"])
    vali_mod.run_validation(cred_path, output_dir=output_dir)

    artefacts["validation"] = os.path.join(output_dir, "validation_results.json")
    logger.info("Validation → %s", artefacts["validation"])

    # ── STEP 4 — METADATA/ ────────────────────────────────────────────────────
    print("\n▶  STEP 4/8 — Metadata Extraction  [METADATA/]")
    print("-" * 60)

    meta_mod              = _load("agent_metadata", agents["metadata"])
    _, metadata_path      = meta_mod.run_metadata(cred_path, output_dir=output_dir)
    artefacts["metadata"] = metadata_path
    logger.info("Metadata → %s", metadata_path)

    # ── STEP 5 — PIPELINE/ ────────────────────────────────────────────────────
    print("\n▶  STEP 5/8 — Pipeline Strategy  [PIPELINE/]")
    print("-" * 60)

    pipe_mod              = _load("agent_pipeline", agents["pipeline"])
    _, strategy_path      = pipe_mod.run_pipeline_strategy(
        mca_path=cred_path,
        metadata_path=metadata_path,
        output_dir=output_dir,
    )
    artefacts["strategy"] = strategy_path
    logger.info("Strategy → %s", strategy_path)

    # ── STEP 6 — SCHEMA/ ──────────────────────────────────────────────────────
    print("\n▶  STEP 6/8 — Schema Mapping  [SCHEMA/]")
    print("-" * 60)

    schema_mod          = _load("agent_schema", agents["schema"])
    _, schema_path      = schema_mod.run_schema_mapping(
        strategy_path=strategy_path,
        metadata_path=metadata_path,
        output_dir=output_dir,
    )
    artefacts["schema"] = schema_path
    logger.info("Schema → %s", schema_path)

    # ── STEP 7 — TABLE/ ───────────────────────────────────────────────────────
    print("\n▶  STEP 7/8 — Table Creation  [TABLE/]")
    print("-" * 60)

    db_config        = load_session_config(config_path)
    table_mod        = _load("agent_table", agents["Table"])
    _, table_path    = table_mod.run_table_creation(
        schema_path=schema_path,
        workspace_url=db_config["databricks_workspace_url"],
        warehouse_id=db_config["databricks_warehouse_id"],
        token=db_config["databricks_token"],
        catalog=db_config["catalog"],
        schema_name=db_config["schema"],
        output_dir=output_dir,
    )
    artefacts["table_creation"] = table_path
    logger.info("Table creation → %s", table_path)

    # ── STEP 8 — FINAL_GEN/ ───────────────────────────────────────────────────
    print("\n▶  STEP 8/8 — Migration Plan Generator  [FINAL_GEN/]")
    print("-" * 60)

    final_mod             = _load("agent_final_gen", agents["final_gen"])
    _, migration_path     = final_mod.run_migration_plan(
        credentials_path=cred_path,
        table_creation_path=table_path,
        strategy_path=strategy_path,
        output_dir=output_dir,
    )
    artefacts["migration_plan"] = migration_path
    logger.info("Migration plan → %s", migration_path)

    # ── SUMMARY ───────────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  ✅  ALL STEPS COMPLETE")
    print("=" * 60)
    print(f"\n  Output : {os.path.abspath(output_dir)}\n")
    print("  Artefacts:")
    for name, path in artefacts.items():
        print(f"    {name:<20} → {path}")
    print(f"\n  NEXT: Upload '{migration_path}' to Databricks and run execution.py\n")

    manifest_path = os.path.join(output_dir, f"manifest_{timestamp}.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(artefacts, f, indent=2)
    logger.info("Manifest → %s", manifest_path)

    return artefacts