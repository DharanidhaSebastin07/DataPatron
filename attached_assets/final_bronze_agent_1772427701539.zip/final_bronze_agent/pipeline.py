# # import json
# # import os
# # from typing import Dict, Any, List


# # class PipelineStrategyAgent:

# #     def __init__(self, mca_file: str, metadata_file: str, output_file: str = "strategy.json"):
# #         self.mca_file = mca_file
# #         self.metadata_file = metadata_file
# #         self.output_file = output_file

# #     # ==========================================================
# #     # ENTRY POINT
# #     # ==========================================================
# #     def execute(self):
# #         mca_config = self._load_json(self.mca_file)
# #         metadata = self._load_json(self.metadata_file)

# #         strategy_output = {
# #             "session_id": mca_config.get("session_id"),
# #             "pipelines": []
# #         }

# #         for pipeline in mca_config.get("pipelines", []):
# #             pipeline_strategy = self._build_pipeline_strategy(pipeline, metadata)
# #             strategy_output["pipelines"].append(pipeline_strategy)

# #         self._save_json(strategy_output)
# #         print(f"Strategy file created: {self.output_file}")

# #     # ==========================================================
# #     # CORE STRATEGY LOGIC (FIXED)
# #     # ==========================================================
# #     def _build_pipeline_strategy(self, pipeline: Dict[str, Any], metadata: Dict[str, Any]):

# #         source_type = pipeline["source_type"]
# #         ingestion_mode = pipeline.get("ingestion_mode", "full")
# #         schedule = pipeline.get("schedule", "one_time")

# #         tables_strategy = []

# #         # 🔥 FIX: Only use metadata for this pipeline's source type
# #         for source_meta in metadata.get("sources", []):

# #             if source_meta.get("source_type") != source_type:
# #                 continue

# #             for table_name, sample_rows in source_meta.get("sample_data", {}).items():

# #                 row_count_estimate = len(sample_rows)

# #                 watermark_candidates = self._detect_watermark_candidates(sample_rows)
# #                 selected_watermark = self._select_watermark(watermark_candidates)

# #                 write_strategy = self._decide_write_strategy(
# #                     ingestion_mode,
# #                     selected_watermark
# #                 )

# #                 partition_column = self._decide_partition(sample_rows, row_count_estimate)
# #                 parallelism = self._decide_parallelism(row_count_estimate)

# #                 tables_strategy.append({
# #                     "table_name": table_name,
# #                     "write_strategy": write_strategy,
# #                     "watermark_column": selected_watermark,
# #                     "partition_by": partition_column,
# #                     "parallelism": parallelism
# #                 })

# #         return {
# #             "pipeline_id": pipeline["pipeline_id"],
# #             "source_type": source_type,
# #             "engine": self._select_engine(source_type),
# #             "ingestion_mode": ingestion_mode,
# #             "schedule": schedule,
# #             "tables": tables_strategy
# #         }

# #     # ==========================================================
# #     # RULE-BASED DECISIONS
# #     # ==========================================================

# #     def _select_engine(self, source_type: str) -> str:
# #         return "spark"

# #     def _decide_write_strategy(self, ingestion_mode: str, watermark_column: str) -> str:
# #         if ingestion_mode == "full":
# #             return "append"
# #         if ingestion_mode == "incremental" and watermark_column:
# #             return "merge"
# #         return "append"

# #     def _decide_partition(self, sample_rows: List[Dict], row_count: int):
# #         if not sample_rows:
# #             return None

# #         columns = sample_rows[0].keys()

# #         for col in columns:
# #             if "date" in col.lower() and row_count > 1000:
# #                 return [col]

# #         return None

# #     def _decide_parallelism(self, row_count: int) -> int:
# #         if row_count < 1000:
# #             return 2
# #         elif row_count < 10000:
# #             return 4
# #         elif row_count < 100000:
# #             return 8
# #         return 16

# #     def _detect_watermark_candidates(self, sample_rows: List[Dict]) -> List[str]:
# #         if not sample_rows:
# #             return []

# #         candidates = []
# #         columns = sample_rows[0].keys()

# #         for col in columns:
# #             name = col.lower()
# #             if any(keyword in name for keyword in ["update", "modified", "timestamp", "date"]):
# #                 candidates.append(col)

# #         return candidates

# #     def _select_watermark(self, candidates: List[str]) -> str:
# #         return candidates[0] if candidates else None

# #     # ==========================================================
# #     # UTILITIES
# #     # ==========================================================

# #     def _load_json(self, path: str) -> Dict:
# #         with open(path, "r") as f:
# #             return json.load(f)

# #     def _save_json(self, data: Dict):
# #         with open(self.output_file, "w") as f:
# #             json.dump(data, f, indent=2)


# # # ==========================================================
# # # PROGRAMMATIC ENTRY  (used by orchestrator)
# # # ==========================================================

# # def run_pipeline_strategy(mca_path: str, metadata_path: str, output_dir: str = ".") -> tuple:
# #     """
# #     Build pipeline strategies and save to strategy.json.

# #     Args:
# #         mca_path:     Path to credentials.json (contains pipeline info).
# #         metadata_path: Path to metadata.json.
# #         output_dir:   Directory to save strategy.json.

# #     Returns:
# #         Tuple of (strategy_dict, strategy_filepath).
# #     """
# #     os.makedirs(output_dir, exist_ok=True)
# #     strategy_path = os.path.join(output_dir, "strategy.json")

# #     agent = PipelineStrategyAgent(mca_path, metadata_path, output_file=strategy_path)
# #     agent.execute()

# #     with open(strategy_path, "r") as f:
# #         strategy = json.load(f)

# #     return strategy, strategy_path


# # # ==========================================================
# # # RUN  (standalone CLI)
# # # ==========================================================
# # if __name__ == "__main__":
# #     mca_path = input("Enter MCA JSON path: ").strip()
# #     metadata_path = input("Enter Metadata JSON path: ").strip()

# #     agent = PipelineStrategyAgent(mca_path, metadata_path)
# #     agent.execute()


# import json
# import os
# from typing import Dict, Any, List


# class PipelineStrategyAgent:

#     def __init__(self, mca_file: str, metadata_file: str, output_file: str = "strategy.json"):
#         self.mca_file = mca_file
#         self.metadata_file = metadata_file
#         self.output_file = output_file

#     # ==========================================================
#     # ENTRY POINT
#     # ==========================================================
#     def execute(self):
#         mca_config = self._load_json(self.mca_file)
#         metadata = self._load_json(self.metadata_file)

#         strategy_output = {
#             "session_id": mca_config.get("session_id"),
#             "pipelines": []
#         }

#         for pipeline in mca_config.get("pipelines", []):
#             pipeline_strategy = self._build_pipeline_strategy(pipeline, metadata)
#             strategy_output["pipelines"].append(pipeline_strategy)

#         self._save_json(strategy_output)
#         print(f"Strategy file created: {self.output_file}")

#     # ==========================================================
#     # CORE STRATEGY LOGIC (HARDENED)
#     # ==========================================================
#     def _build_pipeline_strategy(self, pipeline: Dict[str, Any], metadata: Dict[str, Any]):

#         source_type = pipeline["source_type"]
#         ingestion_mode = pipeline.get("ingestion_mode", "full")
#         schedule = pipeline.get("schedule", "one_time")

#         tables_strategy = []

#         for source_meta in metadata.get("sources", []):

#             if source_meta.get("source_type") != source_type:
#                 continue

#             sample_data = source_meta.get("sample_data", {})

#             if not isinstance(sample_data, dict):
#                 continue

#             for table_name, sample_rows in sample_data.items():

#                 # -----------------------------
#                 # 🔥 FIX: ensure list-of-dicts
#                 # -----------------------------
#                 if not isinstance(sample_rows, list):
#                     continue

#                 if not sample_rows:
#                     continue

#                 first_row = sample_rows[0]

#                 # skip invalid rows (string / number / etc.)
#                 if not isinstance(first_row, dict):
#                     continue

#                 row_count_estimate = len(sample_rows)

#                 watermark_candidates = self._detect_watermark_candidates(sample_rows)
#                 selected_watermark = self._select_watermark(watermark_candidates)

#                 write_strategy = self._decide_write_strategy(
#                     ingestion_mode,
#                     selected_watermark
#                 )

#                 partition_column = self._decide_partition(sample_rows, row_count_estimate)
#                 parallelism = self._decide_parallelism(row_count_estimate)

#                 tables_strategy.append({
#                     "table_name": table_name,
#                     "write_strategy": write_strategy,
#                     "watermark_column": selected_watermark,
#                     "partition_by": partition_column,
#                     "parallelism": parallelism
#                 })

#         # -------------------------------------------------
#         # 🔥 NEW: add watermark tracking table for API/stream
#         # -------------------------------------------------
#         needs_watermark_table = source_type in ["api", "stream", "streaming", "kafka"]

#         return {
#             "pipeline_id": pipeline["pipeline_id"],
#             "source_type": source_type,
#             "engine": self._select_engine(source_type),
#             "ingestion_mode": ingestion_mode,
#             "schedule": schedule,
#             "requires_watermark_tracking": needs_watermark_table,
#             "tables": tables_strategy
#         }

#     # ==========================================================
#     # RULE-BASED DECISIONS
#     # ==========================================================

#     def _select_engine(self, source_type: str) -> str:
#         return "spark"

#     def _decide_write_strategy(self, ingestion_mode: str, watermark_column: str) -> str:
#         if ingestion_mode == "full":
#             return "append"
#         if ingestion_mode == "incremental" and watermark_column:
#             return "merge"
#         return "append"

#     def _decide_partition(self, sample_rows: List[Dict], row_count: int):

#         if not sample_rows:
#             return None

#         first_row = sample_rows[0]

#         if not isinstance(first_row, dict):
#             return None

#         columns = first_row.keys()

#         for col in columns:
#             if "date" in col.lower() and row_count > 1000:
#                 return [col]

#         return None

#     def _decide_parallelism(self, row_count: int) -> int:
#         if row_count < 1000:
#             return 2
#         elif row_count < 10000:
#             return 4
#         elif row_count < 100000:
#             return 8
#         return 16

#     def _detect_watermark_candidates(self, sample_rows: List[Dict]):

#         if not sample_rows:
#             return []

#         first_row = sample_rows[0]

#         if not isinstance(first_row, dict):
#             return []

#         candidates = []

#         for col in first_row.keys():
#             name = col.lower()
#             if any(keyword in name for keyword in ["update", "modified", "timestamp", "date"]):
#                 candidates.append(col)

#         return candidates

#     def _select_watermark(self, candidates: List[str]):
#         return candidates[0] if candidates else None

#     # ==========================================================
#     # UTILITIES
#     # ==========================================================

#     def _load_json(self, path: str):
#         with open(path, "r") as f:
#             return json.load(f)

#     def _save_json(self, data: Dict):
#         with open(self.output_file, "w") as f:
#             json.dump(data, f, indent=2)


# # ==========================================================
# # PROGRAMMATIC ENTRY
# # ==========================================================

# def run_pipeline_strategy(mca_path: str, metadata_path: str, output_dir: str = "."):

#     os.makedirs(output_dir, exist_ok=True)
#     strategy_path = os.path.join(output_dir, "strategy.json")

#     agent = PipelineStrategyAgent(mca_path, metadata_path, output_file=strategy_path)
#     agent.execute()

#     with open(strategy_path, "r") as f:
#         strategy = json.load(f)

#     return strategy, strategy_path


# # ==========================================================
# # CLI
# # ==========================================================
# if __name__ == "__main__":
#     mca_path = input("Enter MCA JSON path: ").strip()
#     metadata_path = input("Enter Metadata JSON path: ").strip()

#     agent = PipelineStrategyAgent(mca_path, metadata_path)
#     agent.execute()


import json
import os
from typing import Dict, Any, List


class PipelineStrategyAgent:

    def __init__(self, mca_file: str, metadata_file: str, output_file: str = "strategy.json"):
        self.mca_file = mca_file
        self.metadata_file = metadata_file
        self.output_file = output_file

    # ==========================================================
    # ENTRY POINT
    # ==========================================================
    def execute(self):
        mca_config = self._load_json(self.mca_file)
        metadata = self._load_json(self.metadata_file)

        strategy_output = {
            "session_id": mca_config.get("session_id"),
            "pipelines": []
        }

        sources = metadata.get("sources", [])

        for pipeline_index, pipeline in enumerate(mca_config.get("pipelines", [])):
            # -------------------------------------------------------
            # 🔥 FIX: Match each pipeline to its metadata source
            # by INDEX, not by iterating all sources with matching
            # source_type. This prevents duplication when multiple
            # pipelines share the same source_type (e.g. two azure_sql
            # schemas both previously matched ALL azure_sql sources).
            # -------------------------------------------------------
            if pipeline_index >= len(sources):
                # No corresponding metadata source — produce empty tables
                source_meta = {}
            else:
                source_meta = sources[pipeline_index]

            pipeline_strategy = self._build_pipeline_strategy(pipeline, source_meta)
            strategy_output["pipelines"].append(pipeline_strategy)

        self._save_json(strategy_output)
        print(f"Strategy file created: {self.output_file}")

    # ==========================================================
    # CORE STRATEGY LOGIC
    # ==========================================================
    def _build_pipeline_strategy(self, pipeline: Dict[str, Any], source_meta: Dict[str, Any]):

        source_type = pipeline["source_type"]
        ingestion_mode = pipeline.get("ingestion_mode", "full")
        schedule = pipeline.get("schedule", "one_time")

        tables_strategy = []

        sample_data = source_meta.get("sample_data", {})

        if isinstance(sample_data, dict):
            for table_name, sample_rows in sample_data.items():

                if not isinstance(sample_rows, list):
                    continue

                if not sample_rows:
                    continue

                first_row = sample_rows[0]

                if not isinstance(first_row, dict):
                    continue

                row_count_estimate = len(sample_rows)

                watermark_candidates = self._detect_watermark_candidates(sample_rows)
                selected_watermark = self._select_watermark(watermark_candidates)

                write_strategy = self._decide_write_strategy(
                    ingestion_mode,
                    selected_watermark
                )

                partition_column = self._decide_partition(sample_rows, row_count_estimate)
                parallelism = self._decide_parallelism(row_count_estimate)

                tables_strategy.append({
                    "table_name": table_name,
                    "write_strategy": write_strategy,
                    "watermark_column": selected_watermark,
                    "partition_by": partition_column,
                    "parallelism": parallelism
                })

        needs_watermark_table = source_type in ["api", "stream", "streaming", "kafka"]

        return {
            "pipeline_id": pipeline["pipeline_id"],
            "source_type": source_type,
            "engine": self._select_engine(source_type),
            "ingestion_mode": ingestion_mode,
            "schedule": schedule,
            "requires_watermark_tracking": needs_watermark_table,
            "tables": tables_strategy
        }

    # ==========================================================
    # RULE-BASED DECISIONS
    # ==========================================================

    def _select_engine(self, source_type: str) -> str:
        return "spark"

    def _decide_write_strategy(self, ingestion_mode: str, watermark_column: str) -> str:
        if ingestion_mode == "full":
            return "append"
        if ingestion_mode == "incremental" and watermark_column:
            return "merge"
        return "append"

    def _decide_partition(self, sample_rows: List[Dict], row_count: int):

        if not sample_rows:
            return None

        first_row = sample_rows[0]

        if not isinstance(first_row, dict):
            return None

        columns = first_row.keys()

        for col in columns:
            if "date" in col.lower() and row_count > 1000:
                return [col]

        return None

    def _decide_parallelism(self, row_count: int) -> int:
        if row_count < 1000:
            return 2
        elif row_count < 10000:
            return 4
        elif row_count < 100000:
            return 8
        return 16

    def _detect_watermark_candidates(self, sample_rows: List[Dict]):

        if not sample_rows:
            return []

        first_row = sample_rows[0]

        if not isinstance(first_row, dict):
            return []

        candidates = []

        for col in first_row.keys():
            name = col.lower()
            if any(keyword in name for keyword in ["update", "modified", "timestamp", "date"]):
                candidates.append(col)

        return candidates

    def _select_watermark(self, candidates: List[str]):
        return candidates[0] if candidates else None

    # ==========================================================
    # UTILITIES
    # ==========================================================

    def _load_json(self, path: str):
        with open(path, "r") as f:
            return json.load(f)

    def _save_json(self, data: Dict):
        with open(self.output_file, "w") as f:
            json.dump(data, f, indent=2)


# ==========================================================
# PROGRAMMATIC ENTRY
# ==========================================================

def run_pipeline_strategy(mca_path: str, metadata_path: str, output_dir: str = "."):

    os.makedirs(output_dir, exist_ok=True)
    strategy_path = os.path.join(output_dir, "strategy.json")

    agent = PipelineStrategyAgent(mca_path, metadata_path, output_file=strategy_path)
    agent.execute()

    with open(strategy_path, "r") as f:
        strategy = json.load(f)

    return strategy, strategy_path


# ==========================================================
# CLI
# ==========================================================
if __name__ == "__main__":
    mca_path = input("Enter MCA JSON path: ").strip()
    metadata_path = input("Enter Metadata JSON path: ").strip()

    agent = PipelineStrategyAgent(mca_path, metadata_path)
    agent.execute()