# import json
# import os
# import datetime
# from typing import Dict, List, Any


# class SchemaMappingAgent:

#     def __init__(self, strategy_file: str, metadata_file: str, output_file: str = "schema_output.json"):
#         self.strategy_file = strategy_file
#         self.metadata_file = metadata_file
#         self.output_file = output_file

#     # ==========================================================
#     # ENTRY POINT
#     # ==========================================================
#     def execute(self):
#         strategy = self._load_json(self.strategy_file)
#         metadata = self._load_json(self.metadata_file)

#         schema_output = {
#             "session_id": strategy.get("session_id"),
#             "tables": []
#         }

#         processed_tables = set()

#         for pipeline in strategy.get("pipelines", []):
#             for table in pipeline.get("tables", []):

#                 normalized_name = self._normalize_table_name(table["table_name"])

#                 if normalized_name in processed_tables:
#                     continue

#                 table_schema = self._build_table_schema(
#                     table,
#                     metadata
#                 )

#                 schema_output["tables"].append(table_schema)
#                 processed_tables.add(normalized_name)

#         self._save_json(schema_output)
#         print(f"Schema mapping file created: {self.output_file}")

#     # ==========================================================
#     # BUILD TABLE SCHEMA
#     # ==========================================================
#     def _build_table_schema(self, table_strategy: Dict, metadata: Dict):

#         table_name = table_strategy["table_name"]
#         write_strategy = table_strategy["write_strategy"]
#         watermark_column = table_strategy.get("watermark_column")
#         partition_by = table_strategy.get("partition_by")

#         sample_rows = self._find_sample_data(metadata, table_name)

#         inferred_columns = self._infer_schema(sample_rows)

#         primary_key = None
#         if write_strategy == "merge":
#             primary_key = self._detect_primary_key(inferred_columns)

#         # Governance columns
#         inferred_columns.append({"name": "ingestion_ts", "type": "TIMESTAMP"})
#         inferred_columns.append({"name": "source_system", "type": "STRING"})

#         ddl = self._generate_ddl(
#             table_name,
#             inferred_columns,
#             partition_by
#         )

#         return {
#             "table_name": self._normalize_table_name(table_name),
#             "columns": inferred_columns,
#             "primary_key": primary_key,
#             "watermark_column": watermark_column,
#             "partition_by": partition_by,
#             "ddl": ddl
#         }

#     # ==========================================================
#     # SCHEMA INFERENCE
#     # ==========================================================
#     def _infer_schema(self, sample_rows: List[Dict]) -> List[Dict]:
#         if not sample_rows:
#             return []

#         schema = []
#         first_row = sample_rows[0]

#         for col, value in first_row.items():
#             col_type = self._map_type(value)
#             schema.append({
#                 "name": col.lower(),
#                 "type": col_type
#             })

#         return schema

#     def _map_type(self, value: Any) -> str:
#         if isinstance(value, bool):
#             return "BOOLEAN"
#         if isinstance(value, int):
#             return "BIGINT"
#         if isinstance(value, float):
#             return "DOUBLE"
#         if isinstance(value, str):
#             if self._is_date(value):
#                 return "DATE"
#             return "STRING"
#         return "STRING"

#     def _is_date(self, value: str) -> bool:
#         try:
#             datetime.datetime.strptime(value, "%Y-%m-%d")
#             return True
#         except:
#             return False

#     # ==========================================================
#     # PRIMARY KEY DETECTION
#     # ==========================================================
#     def _detect_primary_key(self, columns: List[Dict]) -> str:
#         for col in columns:
#             name = col["name"]
#             if name.endswith("_id") or "key" in name:
#                 return name
#         return None

#     # ==========================================================
#     # DDL GENERATION
#     # ==========================================================
#     def _generate_ddl(self, table_name: str, columns: List[Dict], partition_by: List[str]) -> str:

#         normalized_name = self._normalize_table_name(table_name)

#         column_defs = ",\n    ".join(
#             [f"{col['name']} {col['type']}" for col in columns]
#         )

#         ddl = f"""
# CREATE TABLE IF NOT EXISTS {normalized_name} (
#     {column_defs}
# )
# USING DELTA
# """

#         if partition_by:
#             partitions = ", ".join([p.lower() for p in partition_by])
#             ddl += f"\nPARTITIONED BY ({partitions})"

#         return ddl.strip()

#     # ==========================================================
#     # METADATA MATCHING
#     # ==========================================================
#     def _find_sample_data(self, metadata: Dict, table_name: str) -> List[Dict]:

#         for source in metadata.get("sources", []):
#             for meta_table, rows in source.get("sample_data", {}).items():
#                 if meta_table == table_name:
#                     return rows

#         return []

#     # ==========================================================
#     # CORRECT TABLE NAME NORMALIZATION
#     # ==========================================================
#     def _normalize_table_name(self, table_name: str) -> str:

#         table_name = table_name.strip()

#         # Case 1: Azure format schema.table (but not file extensions)
#         if "." in table_name and not table_name.lower().endswith(".csv"):
#             clean = table_name.split(".")[1]

#         # Case 2: File formats
#         else:
#             clean = table_name

#         # Remove file extensions safely
#         if "." in clean:
#             clean = clean.split(".")[0]

#         clean = clean.replace(" ", "_")
#         clean = clean.lower()

#         return f"bronze.{clean}"

#     # ==========================================================
#     # UTILITIES
#     # ==========================================================
#     def _load_json(self, path: str) -> Dict:
#         with open(path, "r") as f:
#             return json.load(f)

#     def _save_json(self, data: Dict):
#         with open(self.output_file, "w") as f:
#             json.dump(data, f, indent=2)


# # ==========================================================
# # PROGRAMMATIC ENTRY  (used by orchestrator)
# # ==========================================================

# def run_schema_mapping(strategy_path: str, metadata_path: str, output_dir: str = ".") -> tuple:
#     """
#     Map schemas and generate DDL, saving results to schema_output.json.

#     Args:
#         strategy_path: Path to strategy.json.
#         metadata_path: Path to metadata.json.
#         output_dir:    Directory to save schema_output.json.

#     Returns:
#         Tuple of (schema_dict, schema_filepath).
#     """
#     os.makedirs(output_dir, exist_ok=True)
#     schema_path = os.path.join(output_dir, "schema_output.json")

#     agent = SchemaMappingAgent(strategy_path, metadata_path, output_file=schema_path)
#     agent.execute()

#     with open(schema_path, "r") as f:
#         schema = json.load(f)

#     return schema, schema_path


# # ==========================================================
# # RUN  (standalone CLI)
# # ==========================================================

# if __name__ == "__main__":
#     strategy_path = input("Enter Strategy JSON path: ").strip()
#     metadata_path = input("Enter Metadata JSON path: ").strip()

#     agent = SchemaMappingAgent(strategy_path, metadata_path)
#     agent.execute()


import json
import os
import datetime
from typing import Dict, List, Any


class SchemaMappingAgent:

    def __init__(self, strategy_file: str, metadata_file: str, output_file: str = "schema_output.json"):
        self.strategy_file = strategy_file
        self.metadata_file = metadata_file
        self.output_file = output_file

    # ==========================================================
    # ENTRY POINT
    # ==========================================================
    def execute(self):
        strategy = self._load_json(self.strategy_file)
        metadata = self._load_json(self.metadata_file)

        schema_output = {
            "session_id": strategy.get("session_id"),
            "tables": []
        }

        processed_tables = set()

        for pipeline in strategy.get("pipelines", []):
            for table in pipeline.get("tables", []):

                normalized_name = self._normalize_table_name(table["table_name"])

                if normalized_name in processed_tables:
                    continue

                table_schema = self._build_table_schema(
                    table,
                    metadata
                )

                schema_output["tables"].append(table_schema)
                processed_tables.add(normalized_name)

        self._save_json(schema_output)
        print(f"Schema mapping file created: {self.output_file}")

    # ==========================================================
    # BUILD TABLE SCHEMA
    # ==========================================================
    def _build_table_schema(self, table_strategy: Dict, metadata: Dict):

        table_name = table_strategy["table_name"]
        write_strategy = table_strategy["write_strategy"]
        watermark_column = table_strategy.get("watermark_column")
        partition_by = table_strategy.get("partition_by")

        sample_rows = self._find_sample_data(metadata, table_name)

        inferred_columns = self._infer_schema(sample_rows)

        primary_key = None
        if write_strategy == "merge":
            primary_key = self._detect_primary_key(inferred_columns)

        ddl = self._generate_ddl(
            table_name,
            inferred_columns,
            partition_by
        )

        return {
            "table_name": self._normalize_table_name(table_name),
            "columns": inferred_columns,
            "primary_key": primary_key,
            "watermark_column": watermark_column,
            "partition_by": partition_by,
            "ddl": ddl
        }

    # ==========================================================
    # SCHEMA INFERENCE
    # ==========================================================
    def _infer_schema(self, sample_rows: List[Dict]) -> List[Dict]:
        if not sample_rows:
            return []

        schema = []
        first_row = sample_rows[0]

        for col, value in first_row.items():
            col_type = self._map_type(value)
            schema.append({
                "name": col.lower(),
                "type": col_type
            })

        return schema

    def _map_type(self, value: Any) -> str:
        if isinstance(value, bool):
            return "BOOLEAN"
        if isinstance(value, int):
            return "BIGINT"
        if isinstance(value, float):
            return "DOUBLE"
        if isinstance(value, str):
            if self._is_date(value):
                return "DATE"
            return "STRING"
        return "STRING"

    def _is_date(self, value: str) -> bool:
        try:
            datetime.datetime.strptime(value, "%Y-%m-%d")
            return True
        except:
            return False

    # ==========================================================
    # PRIMARY KEY DETECTION
    # ==========================================================
    def _detect_primary_key(self, columns: List[Dict]) -> str:
        for col in columns:
            name = col["name"]
            if name.endswith("_id") or "key" in name:
                return name
        return None

    # ==========================================================
    # DDL GENERATION
    # ==========================================================
    def _generate_ddl(self, table_name: str, columns: List[Dict], partition_by: List[str]) -> str:

        normalized_name = self._normalize_table_name(table_name)

        column_defs = ",\n    ".join(
            [f"{col['name']} {col['type']}" for col in columns]
        )

        ddl = f"""
CREATE TABLE IF NOT EXISTS {normalized_name} (
    {column_defs}
)
USING DELTA
"""

        if partition_by:
            partitions = ", ".join([p.lower() for p in partition_by])
            ddl += f"\nPARTITIONED BY ({partitions})"

        return ddl.strip()

    # ==========================================================
    # METADATA MATCHING
    # ==========================================================
    def _find_sample_data(self, metadata: Dict, table_name: str) -> List[Dict]:

        for source in metadata.get("sources", []):
            for meta_table, rows in source.get("sample_data", {}).items():
                if meta_table == table_name:
                    return rows

        return []

    # ==========================================================
    # CORRECT TABLE NAME NORMALIZATION
    # ==========================================================
    def _normalize_table_name(self, table_name: str) -> str:

        table_name = table_name.strip()

        # Case 1: Azure format schema.table (but not file extensions)
        if "." in table_name and not table_name.lower().endswith(".csv"):
            clean = table_name.split(".")[1]

        # Case 2: File formats
        else:
            clean = table_name

        # Remove file extensions safely
        if "." in clean:
            clean = clean.split(".")[0]

        clean = clean.replace(" ", "_")
        clean = clean.lower()

        return f"bronze.{clean}"

    # ==========================================================
    # UTILITIES
    # ==========================================================
    def _load_json(self, path: str) -> Dict:
        with open(path, "r") as f:
            return json.load(f)

    def _save_json(self, data: Dict):
        with open(self.output_file, "w") as f:
            json.dump(data, f, indent=2)


# ==========================================================
# PROGRAMMATIC ENTRY  (used by orchestrator)
# ==========================================================

def run_schema_mapping(strategy_path: str, metadata_path: str, output_dir: str = ".") -> tuple:
    """
    Map schemas and generate DDL, saving results to schema_output.json.

    Args:
        strategy_path: Path to strategy.json.
        metadata_path: Path to metadata.json.
        output_dir:    Directory to save schema_output.json.

    Returns:
        Tuple of (schema_dict, schema_filepath).
    """
    os.makedirs(output_dir, exist_ok=True)
    schema_path = os.path.join(output_dir, "schema_output.json")

    agent = SchemaMappingAgent(strategy_path, metadata_path, output_file=schema_path)
    agent.execute()

    with open(schema_path, "r") as f:
        schema = json.load(f)

    return schema, schema_path


# ==========================================================
# RUN  (standalone CLI)
# ==========================================================

if __name__ == "__main__":
    strategy_path = input("Enter Strategy JSON path: ").strip()
    metadata_path = input("Enter Metadata JSON path: ").strip()

    agent = SchemaMappingAgent(strategy_path, metadata_path)
    agent.execute()