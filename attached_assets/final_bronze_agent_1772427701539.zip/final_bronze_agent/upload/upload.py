"""
========================================================
Bronze Ingestion Platform — Volume Uploader
Version: 1.0

Creates a Unity Catalog Volume in Databricks (if it does
not already exist) and uploads migration_plan.json into it
automatically.

Usage:
    python upload_plan.py

Reads Databricks credentials from:
    session_output/session_config.json  (written by orchestrator)

Or prompts you if that file isn't found.
========================================================
"""

import json
import os
import sys
import glob
import logging
import requests

# =============================================================================
# LOGGING
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("VolumeUploader")


# =============================================================================
# CONFIG LOADER
# =============================================================================

def load_config(config_path: str = "session_output/session_config.json") -> dict:
    """
    Load Databricks credentials.  Falls back to interactive prompts
    if session_config.json doesn't exist.
    """
    if os.path.exists(config_path):
        logger.info("Loading config from: %s", config_path)
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)

    print("\n" + "=" * 60)
    print("  DATABRICKS CREDENTIALS")
    print("=" * 60)
    return {
        "databricks_workspace_url": input("  Databricks workspace URL : ").strip().rstrip("/"),
        "databricks_token":         input("  Personal Access Token    : ").strip(),
        "catalog":                  input("  Catalog name             : ").strip(),
        "schema":                   input("  Schema name              : ").strip(),
    }


# =============================================================================
# FIND LATEST MIGRATION PLAN
# =============================================================================

def find_latest_migration_plan(session_output_dir: str = "session_output") -> str:
    """
    Auto-detect the most recently created migration_plan.json across
    all timestamped run folders inside session_output/.
    """
    pattern = os.path.join(session_output_dir, "run_*", "migration_plan.json")
    matches = sorted(glob.glob(pattern))          # sorted = oldest first

    if not matches:
        raise FileNotFoundError(
            f"No migration_plan.json found in any run folder under '{session_output_dir}'.\n"
            "Run orchestrator.py first."
        )

    latest = matches[-1]                          # most recent run
    logger.info("Found migration plan: %s", latest)
    return latest


# =============================================================================
# DATABRICKS VOLUME API HELPERS
# =============================================================================

def _headers(token: str) -> dict:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def create_volume_if_not_exists(
    workspace_url: str,
    token: str,
    catalog: str,
    schema: str,
    volume: str,
) -> None:
    """
    Create a Unity Catalog MANAGED volume if it doesn't already exist.
    Uses POST /api/2.1/unity-catalog/volumes
    """
    url = f"{workspace_url}/api/2.1/unity-catalog/volumes"

    # Check if it already exists
    list_resp = requests.get(
        url,
        headers=_headers(token),
        params={"catalog_name": catalog, "schema_name": schema},
        timeout=30,
    )

    if list_resp.status_code == 200:
        volumes = list_resp.json().get("volumes", [])
        existing = [v["name"] for v in volumes]
        if volume in existing:
            logger.info("Volume already exists: %s.%s.%s", catalog, schema, volume)
            return

    # Create the volume
    payload = {
        "catalog_name": catalog,
        "schema_name":  schema,
        "name":         volume,
        "volume_type":  "MANAGED",
    }
    create_resp = requests.post(
        url,
        headers=_headers(token),
        json=payload,
        timeout=30,
    )

    if create_resp.status_code in (200, 201):
        logger.info("Volume created: %s.%s.%s", catalog, schema, volume)
    else:
        raise RuntimeError(
            f"Failed to create volume '{volume}'.\n"
            f"Status {create_resp.status_code}: {create_resp.text}"
        )


def upload_file_to_volume(
    workspace_url: str,
    token: str,
    catalog: str,
    schema: str,
    volume: str,
    local_path: str,
    remote_filename: str | None = None,
) -> str:
    """
    Upload a local file to a Unity Catalog Volume using the Files API.
    PUT /api/2.0/fs/files/Volumes/{catalog}/{schema}/{volume}/{filename}

    Returns the full volume path of the uploaded file.
    """
    filename = remote_filename or os.path.basename(local_path)
    volume_path = f"/Volumes/{catalog}/{schema}/{volume}/{filename}"
    url = f"{workspace_url}/api/2.0/fs/files{volume_path}"

    with open(local_path, "rb") as f:
        file_bytes = f.read()

    upload_resp = requests.put(
        url,
        headers={"Authorization": f"Bearer {token}"},   # no Content-Type — binary upload
        data=file_bytes,
        timeout=60,
    )

    if upload_resp.status_code in (200, 201, 204):
        logger.info("Uploaded → %s", volume_path)
        return volume_path
    else:
        raise RuntimeError(
            f"Upload failed for '{filename}'.\n"
            f"Status {upload_resp.status_code}: {upload_resp.text}"
        )


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:

    print("\n" + "=" * 60)
    print("  BRONZE INGESTION PLATFORM — VOLUME UPLOADER")
    print("=" * 60)

    # ── 1. Load credentials ───────────────────────────────────────────────────
    cfg           = load_config()
    workspace_url = cfg["databricks_workspace_url"].rstrip("/")
    token         = cfg["databricks_token"]
    catalog       = cfg["catalog"]
    schema        = cfg["schema"]

    # ── 2. Volume name (default: agent_plans) ─────────────────────────────────
    default_volume = "agent_plans"
    volume_input   = input(
        f"\n  Volume name to upload into [{default_volume}]: "
    ).strip()
    volume = volume_input or default_volume

    # ── 3. Find the latest migration plan ────────────────────────────────────
    try:
        migration_plan_path = find_latest_migration_plan()
    except FileNotFoundError as exc:
        print(f"\n❌  {exc}")
        sys.exit(1)

    print(f"\n  Plan file  : {migration_plan_path}")
    print(f"  Uploading to: {workspace_url}/Volumes/{catalog}/{schema}/{volume}/\n")

    # ── 4. Create volume if needed ────────────────────────────────────────────
    print("▶  Creating volume (if not exists)…")
    try:
        create_volume_if_not_exists(workspace_url, token, catalog, schema, volume)
    except RuntimeError as exc:
        print(f"\n❌  {exc}")
        sys.exit(1)

    # ── 5. Upload migration plan ──────────────────────────────────────────────
    print("▶  Uploading migration_plan.json…")
    try:
        volume_path = upload_file_to_volume(
            workspace_url=workspace_url,
            token=token,
            catalog=catalog,
            schema=schema,
            volume=volume,
            local_path=migration_plan_path,
        )
    except RuntimeError as exc:
        print(f"\n❌  {exc}")
        sys.exit(1)

    # ── 6. Summary ────────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  ✅  UPLOAD COMPLETE")
    print("=" * 60)
    print(f"\n  Volume path : {volume_path}")
    print("\n  NEXT STEP:")
    print(f"  In execution.py set CONFIG to:")
    print(f'  CONFIG = "{volume_path}"\n')


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nUpload interrupted by user.")
    except Exception as exc:
        logger.exception("Uploader failed: %s", exc)
        sys.exit(1)
